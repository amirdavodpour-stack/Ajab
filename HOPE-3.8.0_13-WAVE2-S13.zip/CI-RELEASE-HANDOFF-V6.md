# HOPE 3.8.0+11 — CI Release Handoff V6

This package incorporates the release-gate corrections identified during the 2026-09-02 audit.

## Important

- Pilot Android builds use `BUILD_PROFILE=pilot`.
- `API_BASE_URL` must be supplied by a GitHub Secret/Variable and must use HTTPS.
- The release helper uses Gradle `:app:assembleRelease` as the build source of truth.
- APK discovery is independent of Flutter CLI output-path assumptions.
- APK package, versionName, versionCode, size and SHA-256 are hard-verified before artifact upload.
- `integration_test` remains in the source project; release-specific isolation must be done in a disposable copy when required by CI.
- Production signing remains secret-backed and is not included in this ZIP.

## GitHub

Upload/extract the project so `.github/workflows/main.yml` is present as a real workflow file. Then configure `API_BASE_URL` before dispatching the pilot gate.

## V6 changes

1. Pilot CI is a hard gate: formatting, analyze and tests must pass.
2. Android release build uses Gradle `:app:assembleRelease` directly.
3. Release builds run from a disposable copy with `integration_test` removed only there.
4. APK discovery no longer depends on Flutter CLI artifact-path reporting.
5. Package/version/size/signature/SHA-256 are hard verification gates.
6. Production workflow now consumes the canonical verified APK produced by the isolated builder.
