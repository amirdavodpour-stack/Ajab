export function createProviderRoutes({ authUser, getProvider, publicUser, db, repo, sendJson, HttpError, now }) {
  return async function providerRoutes(req, res, parts) {
    if (req.method !== 'GET' || parts[1] !== 'me') throw new HttpError(404, 'NOT_FOUND', 'Provider route not found');
    const user = await authUser(req);
    let provider = await getProvider(user.id);
    if (!provider) {
      const draft={ id: db.id(), userId: user.id, providerType:'INDIVIDUAL', capacity:'OPEN', verificationStatus:'UNVERIFIED', createdAt:now(), updatedAt:now() };
      provider = process.env.DATABASE_URL ? await repo.upsertProvider(draft) : db.insert('providers', draft);
    }
    return sendJson(res, 200, { ...provider, user: publicUser(user) });
  };
}
