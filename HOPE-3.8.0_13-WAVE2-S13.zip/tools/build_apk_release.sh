#!/usr/bin/env bash
set -euo pipefail

: "${API_BASE_URL:?Set API_BASE_URL, e.g. https://api.example.com/api/v1}"

case "$API_BASE_URL" in
  https://*) ;;
  *) echo 'ERROR: API_BASE_URL must use HTTPS for a release build.' >&2; exit 1 ;;
esac

cd "$(dirname "$0")/.."

BUILD_PROFILE="${BUILD_PROFILE:-pilot}"
case "$BUILD_PROFILE" in
  pilot|production) ;;
  *) echo 'ERROR: BUILD_PROFILE must be production or pilot.' >&2; exit 1 ;;
esac

# Pilot is the safe default for local/CI build helpers. Production must be explicit.
if [[ "$BUILD_PROFILE" == "production" ]]; then
  : "${ANDROID_RELEASE_STORE_FILE:?Set ANDROID_RELEASE_STORE_FILE for a production release}"
  : "${ANDROID_RELEASE_STORE_PASSWORD:?Set ANDROID_RELEASE_STORE_PASSWORD for a production release}"
  : "${ANDROID_RELEASE_KEY_ALIAS:?Set ANDROID_RELEASE_KEY_ALIAS for a production release}"
  : "${ANDROID_RELEASE_KEY_PASSWORD:?Set ANDROID_RELEASE_KEY_PASSWORD for a production release}"
fi

chmod +x android/gradlew
rm -rf build android/build android/app/build .gradle android/.gradle
flutter clean
flutter pub get
flutter gen-l10n
flutter analyze
flutter test --no-pub

export GRADLE_USER_HOME="${GRADLE_USER_HOME:-$PWD/.gradle-release}"
export GRADLE_OPTS="${GRADLE_OPTS:--Dorg.gradle.daemon=false -Dorg.gradle.caching=false -Dorg.gradle.configuration-cache=false -Dorg.gradle.vfs.watch=false -Dorg.gradle.parallel=false}"

encode_define() {
  printf '%s' "$1" | base64 -w0
}

DART_DEFINES="$(encode_define "API_BASE_URL=$API_BASE_URL"),$(encode_define "BUILD_PROFILE=$BUILD_PROFILE")"

./android/gradlew --stop || true
./android/gradlew :app:assembleRelease \
  --no-daemon \
  --stacktrace \
  --console=plain \
  -Pdart-defines="$DART_DEFINES"

mapfile -t APKS < <(
  find \
    android/app/build/outputs/apk \
    build/app/outputs/flutter-apk \
    -type f -name '*.apk' -print 2>/dev/null \
    | sort -u
)

if [[ "${#APKS[@]}" -eq 0 ]]; then
  echo 'ERROR: Gradle succeeded but no APK was discovered.' >&2
  find android/app/build/outputs build/app/outputs -maxdepth 5 -type f 2>/dev/null | sort >&2 || true
  exit 1
fi

APK=""
for candidate in "${APKS[@]}"; do
  if [[ "$candidate" == *"app-release.apk" ]]; then
    APK="$candidate"
    break
  fi
done
if [[ -z "$APK" ]]; then
  APK="${APKS[0]}"
fi

test -s "$APK"
SIZE="$(stat -c '%s' "$APK" 2>/dev/null || stat -f '%z' "$APK")"
test "$SIZE" -gt 1000000

BADGING=''
if command -v aapt >/dev/null 2>&1; then
  BADGING="$(aapt dump badging "$APK")"
  grep -q "package: name='com.hope.marketplace'" <<<"$BADGING" || { echo 'ERROR: wrong applicationId.' >&2; exit 1; }
  grep -q "versionName='3.8.0'" <<<"$BADGING" || { echo 'ERROR: unexpected versionName.' >&2; exit 1; }
  grep -q "versionCode='11'" <<<"$BADGING" || { echo 'ERROR: unexpected versionCode.' >&2; exit 1; }
elif command -v apkanalyzer >/dev/null 2>&1; then
  test "$(apkanalyzer manifest application-id "$APK")" = 'com.hope.marketplace'
  test "$(apkanalyzer manifest version-name "$APK")" = '3.8.0'
  test "$(apkanalyzer manifest version-code "$APK")" = '11'
else
  echo 'ERROR: neither aapt nor apkanalyzer is available for APK metadata verification.' >&2
  exit 1
fi

if command -v apksigner >/dev/null 2>&1; then
  apksigner verify --verbose "$APK"
else
  echo 'ERROR: apksigner is required for release artifact verification.' >&2
  exit 1
fi

mkdir -p artifacts
CANONICAL="artifacts/HOPE-3.8.0+11-${BUILD_PROFILE}.apk"
cp "$APK" "$CANONICAL"

SHA256="$(sha256sum "$CANONICAL" | awk '{print $1}')"
printf '%s  %s\n' "$SHA256" "$(basename "$CANONICAL")" > artifacts/SHA256SUMS.txt
cat > artifacts/VERIFICATION.txt <<EOF
profile=$BUILD_PROFILE
source_apk=$APK
canonical_apk=$CANONICAL
package=com.hope.marketplace
versionName=3.8.0
versionCode=11
size_bytes=$SIZE
sha256=$SHA256
EOF

printf '\nRelease artifact\n-----------------\n'
printf 'Profile: %s\n' "$BUILD_PROFILE"
printf 'APK: %s\n' "$CANONICAL"
printf 'Size: %s bytes\n' "$SIZE"
printf 'SHA-256: %s\n' "$SHA256"
printf 'Signature verification: PASS\n'
