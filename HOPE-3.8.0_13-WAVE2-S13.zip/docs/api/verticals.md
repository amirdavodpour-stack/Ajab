# Vertical registry API (Wave 1 / Session 6)

Read-only. No write endpoints exist yet; `POST/PUT/DELETE` return `405`.

## GET /api/v1/verticals

Returns the active verticals ordered by `sort_order, slug`.

```json
[{ "id": "…", "slug": "jobs", "name": "Jobs", "nameEn": "Jobs",
   "description": "…", "config": {}, "isActive": true, "sortOrder": 0 }]
```

Backed by `repo.listVerticals()` when `DATABASE_URL` is set. Without a
database the in-memory fallback returns the single seeded `jobs` vertical, so
the API shape is identical in both modes.

## GET /api/v1/categories?vertical=&lt;slug&gt;

- **Param absent (default):** behaviour is byte-identical to before Session 6 —
  every active category, ordered by `sort_order, name`. The live jobs vertical
  is therefore unaffected.
- **Param present:** categories are filtered by
  `vertical_id = (SELECT id FROM verticals WHERE slug = $1)`. An unknown slug
  yields `200 []`, not an error.
- **Malformed slug** (anything outside `^[a-z0-9][a-z0-9_-]{0,63}$`, case
  insensitive): `400 INVALID_VERTICAL`. The value is never interpolated into
  SQL; it is always a bound parameter.
- In-memory fallback mode: the legacy dataset belongs to `jobs`, so
  `?vertical=jobs` returns the full list and any other slug returns `[]`.

Categories were backfilled to the `jobs` vertical in Session 3; `vertical_id`
remains nullable in Wave 1, so a row created by older code that skips the
backfill is simply invisible to a scoped query until the next `createSchema`
run self-heals it.
