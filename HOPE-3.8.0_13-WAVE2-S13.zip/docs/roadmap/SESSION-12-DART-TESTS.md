# Session 12 — First real Dart test execution (Wave 2)

Date: 2026-09-03
Toolchain: Flutter 3.47.2 / Dart 3.13.2 (`/tmp/fl/flutter`, session-local),
pub access via a session-local loopback pub mirror (`PUB_HOSTED_URL=http://127.0.0.1:8765`).
Nothing about the mirror is committed.

## 1. `flutter test` — EXECUTED FOR REAL

Command: `flutter test --no-pub` (also re-run with `--reporter json` to enumerate suites,
because the expanded reporter rewrites lines with carriage returns and a plain
`tee`d log under-reports the suite list — an artifact, not a missing test).

Result: **11 suites, 50 tests, 50 pass, 0 fail, 0 skip. `success: true`.**

| Test file | Executed | Result |
| --- | --- | --- |
| test/api_client_test.dart | yes | pass |
| test/auth_controller_test.dart | yes | pass |
| test/create_job_validator_test.dart | yes | pass |
| test/job_vertical_model_test.dart | yes | pass (S8's 7 tests, first execution) |
| test/localization_accessibility_contract_test.dart | yes | pass |
| test/location_runtime_contract_test.dart | yes | pass |
| test/secure_store_test.dart | yes | pass |
| test/smoke_app_test.dart | yes | pass |
| test/transaction_error_contract_test.dart | yes | pass |
| test/ui_components_test.dart | yes | pass |
| test/upload_queue_test.dart | yes | pass |

The Wave 1 debt "Flutter/Dart code authored but never executed" is now retired for the
test suite: every Dart test file in the repo has run at least once, green.

## 2. CI localization count assertion — FIXED

`lib/core/ui/hope_l10n.dart:408-409` contains the wrapper *declaration* and the delegate
*call*, so the raw token `copy_value_irr_ed45261` occurs twice. The gate counted raw
occurrences and asserted 1, so it failed on a correct tree.

Fix (both workflows, declaration-specific):

```
count=$(grep -c 'String copy_value_irr_ed45261(' lib/core/ui/hope_l10n.dart)
test "$count" -eq 1
```

- `.github/workflows/main.yml` (localization gate)
- `.github/workflows/normalize-source.yml` (same assertion, plus its dedupe pass now
  matches on the declaration signature rather than the bare token)

Verified locally: `grep -c 'String copy_value_irr_ed45261(' lib/core/ui/hope_l10n.dart` → `1`.

## 3. `use_build_context_synchronously` in profile_page.dart — FIXED

All four findings resolved by guarding on `mounted` / `context.mounted` after each await
before touching `BuildContext` (`setState`, `ScaffoldMessenger.of(context)`). No
user-visible behaviour change: the same snackbars and refreshes happen, they are just
skipped when the widget is gone.

`dart analyze lib` now reports **0 findings in lib/features/profile/profile_page.dart**.

## 4. Static analysis / formatting state (advisory)

- `dart analyze lib`: 0 errors, 6 warnings, 41 info (47 issues).
- All 6 remaining warnings are pre-existing and confined to
  `lib/core/network/api_client.dart` (5 × `unused_catch_clause`, 1 ×
  `unawaited_return_in_try_block`). Out of Session 12 scope — recorded as a risk.
- `dart format --output=none --set-exit-if-changed lib test`: 49 files, 0 changed. PASS.

## 5. Not done / out of scope

- No feature, schema, route, or payload change.
- No backend work; the backend suite was not re-run (untouched this session).
- `dart analyze` stays advisory, not a gate.
