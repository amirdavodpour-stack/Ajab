# Wave 1 Retrospective — Multi-Vertical Foundations

**Wave:** 1 (Sessions 1–10)
**Status at close:** `wave_complete`
**Date:** 2026-09-03
**Companion documents:** `MULTI-VERTICAL-ROADMAP.md`, `WAVE-1-SESSIONS.md`,
`SESSION-09-REGRESSION-REPORT.md`, `docs/architecture/ADR-001-multi-vertical.md`

---

## 1. Goal of Wave 1

Make the HOPE data model capable of describing more than one vertical, without
changing a single byte of the behaviour the live `jobs` vertical depends on.
Wave 1 was deliberately scoped to *foundations*: registry, columns, read path,
one read-only endpoint, and a policy module. No second vertical was to be
launched, and no jobs payload was to change shape.

---

## 2. What Wave 1 actually delivered

| Session | Deliverable | Status |
|---|---|---|
| 1 | `ADR-001-multi-vertical.md`; every existing `jobs`/`categories`/`job_applications` column classified; rejected alternatives recorded | Delivered |
| 2 | `verticals` table + unique slug index + idempotent `jobs` seed row | Delivered (DDL authored, never executed against Postgres) |
| 3 | `categories.vertical_id` nullable FK, idempotent backfill, `categories_vertical_idx` | Delivered (same caveat) |
| 4 | `jobs.vertical_id` nullable FK + `jobs.attributes JSONB NOT NULL DEFAULT '{}'` + `jobs_vertical_idx` | Delivered (same caveat) |
| 5 | Read path: `jobFromRow` / `categoryFromRow` expose `verticalId` / `attributes` | Delivered |
| 6 | Read-only `GET /verticals`; optional `?vertical=` filter on categories | Delivered |
| 7 | `backend/src/policies/attributes.js`, jobs hard-exempt, currently unwired | Delivered as dead code by design |
| 8 | Flutter `HopeJob.verticalId` / `.attributes` with omit-when-empty `toMap()`; `jobView()` whitelist extended | Delivered, **not executed** |
| 9 | Regression session: full backend suite run for real; two pre-existing failures fixed | Delivered |
| 10 | This retro + `WAVE-2-SESSIONS.md` | This document |

### Verified facts at wave close

- Backend offline suite: **318 tests / 317 pass / 0 fail / 1 skip, exit 0**
  on Node v24.14.0 (`npm ci` + `npm run test:offline`, ~35s).
- The single skip is `postgres-bootstrap-integration`, which self-skips with no
  `DATABASE_URL`.
- `npm run check` passes.
- All Wave 1 schema work is additive; no column was dropped, renamed, or
  retyped, and no jobs response body changed shape.

---

## 3. What Wave 1 did **not** deliver

These are stated plainly because the STATE block and this retro are the only
places a future session will look before trusting the wave.

1. **No Postgres execution.** Every line of Wave 1 DDL — the `verticals` table,
   both `vertical_id` columns, `jobs.attributes`, all three indexes, both
   backfills — has only ever been read by static tests. It has never been
   applied to a real database. The correctness of the SQL is *asserted*, not
   *demonstrated*.
2. **No Dart execution.** `dart analyze` and `flutter test` have never run in
   this project, in any session. `test/job_vertical_model_test.dart` (Session 8,
   7 tests) has never executed. Two independent blockers: `pubspec.yaml` pins
   `flutter: '>=3.47.0'` while the newest obtainable stable is 3.38.3, and
   pub.dev is TLS-unreachable from the session sandbox.
3. **No lint.** The backend has no ESLint and no Prettier — no config file, no
   devDependency. Nothing enforces style or catches unused/shadowed bindings.
4. **No supply-chain scan.** `npm audit` cannot run in-sandbox; the registry
   mirror has no audit endpoint. GitHub CI is the only scanner.
5. **No second vertical.** `policies/attributes.js` is unreachable code until a
   non-jobs write path calls it, and existing rows are unvalidated.

---

## 4. What went well

- **Additive-only discipline held.** Choosing nullable FKs and a defaulted
  JSONB column meant every Wave 1 migration is safe to apply to a live table
  and safe to run twice. Nothing in Wave 1 requires a maintenance window.
- **The `toMap()` omit-when-empty rule (S8)** kept jobs payloads byte-identical,
  which is what made "backward compatibility" checkable rather than aspirational.
- **Static contract tests were the right tool.** They run with no database and
  no Flutter SDK, which is the only reason Wave 1 had any Dart-side safety net
  at all.
- **Session 9 was worth its budget.** It converted an assumed-green suite into a
  measured one and found two real, pre-existing failures.

## 5. What went badly

- **Seven sessions of code were written before anything was executed.** Sessions
  2–8 all reported success against static analysis alone. Session 9 then found
  the suite had been red the whole time. Verification should have been Session 2,
  not Session 9.
- **The toolchain was never established.** A wave that produces Flutter code
  should have resolved the Flutter SDK pin in its first session. Instead the
  blocker was discovered at the end, after the dependent code was already merged.
- **ZIP handoffs silently drop POSIX mode bits**, which broke a release-validation
  test and cost debugging time. This is now a documented unzip ritual.
- **`jobView()` being a whitelist rather than a spread** is a correctness trap:
  any future column added to `jobFromRow` will be silently dropped before it
  reaches the client. It bit nobody in Wave 1 only because S8 remembered it.

## 6. Decisions carried into Wave 2

- The Dart analyzer stays **advisory**. A gate that has never executed cannot be
  certified as enforcing.
- `jobs` is **not** renamed to `listings` in Wave 2 — deferred to Wave 4.
- `offers` is the shared engagement object; `job_applications` stays jobs-only.
- `allowUnknownAttributes` defaults to `true` while verticals are being authored.
- Static contract-test regexes must be whitespace-tolerant; they read formatted
  source, not minified source.

## 7. Debt handed to Wave 2, in priority order

1. `pubspec.yaml` Flutter pin — blocks *all* Dart verification for everyone,
   not just the sandbox.
2. Postgres-backed execution of the Wave 1 DDL.
3. Backend lint adoption (ESLint + Prettier + CI gate).
4. `trust_reports.entity_type` CHECK is limited to `('USER','JOB')` and must
   widen before a second vertical can be reported on.
5. `payments.job_id` is `UNIQUE` and jobs-named; coupling persists until Wave 4.
6. The first non-jobs vertical write path, which is what finally makes
   `policies/attributes.js` live code.
