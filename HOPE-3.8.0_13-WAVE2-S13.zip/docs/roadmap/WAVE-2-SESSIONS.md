# Wave 2 — Session Plan

**Theme:** Make Wave 1 real. Establish the verification the foundations were
built without, then land the first non-jobs vertical write path.

**Entry condition:** Wave 1 closed at `wave_complete` with 318 backend tests
green and every Wave 1 DDL statement unexecuted. Read `WAVE-1-RETRO.md` before
Session 1 of this wave.

**Standing rules for every session in this wave**

- One session = one deliverable. Do not carry work forward silently.
- After unzipping a handoff, first run:
  `chmod +x tools/*.sh backend/scripts/*.sh backend/entrypoint.sh backend/staging/providers/entrypoint.sh`
- Backend work requires Node `>=24` and `npm ci` in `backend/`.
- Full suite is `npm run test:offline` from `backend/` (~35s). It is cheap; run
  it whenever shared code is touched.
- Report what was **executed**, not what was **written**. An unrun gate is
  reported as unrun.

---

## Session 11 — Flutter toolchain unblock (HIGHEST PRIORITY)

- **Deliverable:** a `pubspec.yaml` Flutter SDK constraint that an actually
  obtainable stable SDK satisfies, with evidence, plus a documented pub-fetch
  path (sandbox or CI).
- **Read first:** `pubspec.yaml`, `analysis_options.yaml`, `.github/workflows/main.yml`,
  `WAVE-1-RETRO.md` §3.2.
- **Touch:** `pubspec.yaml`, `pubspec.lock`, CI workflow if needed.
- **Acceptance:** `flutter pub get` completes; the resolved SDK version is
  recorded in the STATE block. If pub.dev remains TLS-unreachable in-session,
  the acceptance moves to CI: a workflow run that proves resolution.
- **Verification:** `flutter pub get`, then `dart analyze` (advisory output
  captured, not yet gating).
- **Note:** do not guess a version. Determine the newest stable, then pin to it.

## Session 12 — First Dart test execution

- **Deliverable:** `flutter test` executed for the first time in this project;
  every failure triaged into "test is wrong" vs "code is wrong" and fixed.
- **Read first:** Session 11 output, `test/job_vertical_model_test.dart`.
- **Acceptance:** a real pass/fail count for the Dart suite exists. Session 8's
  7 model tests have executed.
- **Verification:** `flutter test` (full output recorded in the session report).
- **Blocked by:** Session 11.

## Session 13 — Postgres-backed DDL verification

- **Deliverable:** every Wave 1 DDL statement applied to a real PostgreSQL
  instance via `createSchema`, run twice to prove idempotency.
- **Read first:** `backend/src/db/schema.js`, `backend/tests/postgres-bootstrap-integration*`.
- **Acceptance:** `postgres-bootstrap-integration` runs instead of skipping;
  `verticals`, `categories.vertical_id`, `jobs.vertical_id`, `jobs.attributes`
  and all three indexes verified present; both backfills verified idempotent.
- **Verification:** `DATABASE_URL=... npm test` from `backend/`; the suite's
  skip count must drop to 0.

## Session 13B — Postgres runtime parity (inserted by Session 13)

- **Why:** Session 13 executed the DDL against real PostgreSQL for the first
  time and found the *runtime* path broken, not the schema. With
  `DATABASE_URL` set the full suite is 290 tests / 271 pass / 19 fail.
- **Deliverable:** the Postgres repository facade reaches parity with the
  collection-mode API (starting with `repo.listOffersForJob`, which 500s every
  job-detail request), and the behavioural suites get per-suite database
  isolation (truncate or per-file schema) so they do not leak state.
- **Read first:** `docs/roadmap/SESSION-13-POSTGRES-DDL.md`,
  `backend/src/repository/`, `backend/tests/lib/`.
- **Acceptance:** `DATABASE_URL=... npm run test:offline` passes with 0 skips
  and 0 failures; the offline (collection-mode) suite stays green.
- **Verification:** both suite runs recorded with actual totals.

## Session 14 — Backend lint adoption

- **Deliverable:** ESLint + Prettier config, devDependencies, `npm run lint`
  script, CI gate, and the first-run fix-up commit.
- **Read first:** `backend/package.json`, `.github/workflows/main.yml`.
- **Acceptance:** `npm run lint` exits 0 on a clean tree and is wired into CI.
  Formatting-only churn is kept in its own commit, separate from any fix.
- **Verification:** `npm run lint`, then the full offline suite to prove the
  fix-up changed no behaviour (318 tests still green).
- **Caution:** do not let auto-fix rewrite `backend/src/db/schema.js` SQL
  literals or the source strings that static contract tests match against.

## Session 15 — Widen `trust_reports.entity_type`

- **Deliverable:** the CHECK constraint widened beyond `('USER','JOB')` to a
  vertical-neutral entity set, additively and idempotently.
- **Read first:** ADR-001 §4, `backend/src/db/schema.js`, trust/report routes.
- **Acceptance:** existing `'USER'`/`'JOB'` rows still validate; the new value
  set is accepted; the migration is safe to run twice.
- **Verification:** trust repository test plus the Postgres path from Session 13.

## Session 16 — Vertical config authoring + attribute schema

- **Deliverable:** a real `verticals.config` attribute schema for the first
  non-jobs vertical, and `policies/attributes.js` wired to read it.
- **Read first:** `backend/src/policies/attributes.js` (S7), ADR-001 §5.
- **Acceptance:** the jobs hard-exemption still short-circuits first and is
  covered by a test; the new vertical's schema validates and rejects correctly.
- **Verification:** new unit tests for the policy module + full offline suite.

## Session 17 — First non-jobs vertical write path

- **Deliverable:** create/update for the second vertical, routed through the
  attribute policy, with `vertical_id` set explicitly.
- **Read first:** Session 16 output, `backend/src/repository/core.js`,
  `view_helpers.js`.
- **Acceptance:** writing a non-jobs row validates attributes and persists them;
  writing a jobs row is byte-for-byte unchanged from Wave 1 behaviour.
- **Verification:** full offline suite plus a new write-path test proving jobs
  payload equivalence. `policies/attributes.js` is no longer dead code after
  this session.
- **Reminder:** `jobView()` is a whitelist — any new exposed column must be
  added there explicitly or it never reaches the client.

## Session 18 — Wave 2 retro + Wave 3 plan

- **Deliverable:** `WAVE-2-RETRO.md` and `WAVE-3-SESSIONS.md`; set
  `wave_status: wave_complete`.
- **Acceptance:** the retro states executed-vs-written honestly, as Wave 1's did.
- **Verification:** `node --test tests/wave0-documentation.test.mjs` from `backend/`.

---

## Explicitly out of scope for Wave 2

- Renaming `jobs` to `listings` (Wave 4).
- Decoupling `payments.job_id` (Wave 4).
- Any Flutter UI for the second vertical — Wave 2 is backend write path plus
  toolchain only.
- Promoting the Dart analyzer to an enforcing gate. That may be proposed only
  after Session 12 has produced a real pass/fail baseline.
