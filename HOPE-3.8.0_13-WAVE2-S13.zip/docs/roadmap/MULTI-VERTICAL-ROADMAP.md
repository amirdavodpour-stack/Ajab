# HOPE Marketplace — Multi-Vertical Roadmap

> Reconstructed in Wave 1 / Session 1: this file was missing from the baseline
> zip (`HOPE-3.8.0+11-FINAL`). Content below is derived from the actual
> codebase (`backend/src/db/schema.js`, `backend/src/repository/*`) and from
> the SUPERPROMPT's stated goal. Treat as authoritative going forward.

## Goal

Transform HOPE from a single "jobs" marketplace into a multi-vertical platform
sharing one identity, payments, trust, notification and analytics core, without
any regression to the live jobs vertical.

## Waves

- **Wave 1 — Foundations (current).** Decide and document the model (ADR-001),
  add the additive `verticals` registry + `vertical_id`/`attributes` columns,
  make categories vertical-scoped, keep every jobs API byte-compatible, and
  regression-verify.
- **Wave 2 — Second vertical.** Introduce one real non-jobs vertical end to
  end (taxonomy, attribute schema, listing UI, engagement via `offers`), widen
  `trust_reports.entity_type`, add per-vertical moderation rules.
- **Wave 3 — Discovery & client.** Vertical switcher in the Flutter client,
  vertical-aware search/filtering, per-vertical home and analytics dimensions.
- **Wave 4 — Operations.** Per-vertical fee policies, admin tooling, reporting,
  and de-risking the eventual `jobs` → `listings` rename.

## Invariants

1. Jobs behaviour never changes without an explicit session instruction.
2. All schema changes additive and idempotent, in `createSchema`.
3. Money, trust, notifications and analytics stay vertical-agnostic.
