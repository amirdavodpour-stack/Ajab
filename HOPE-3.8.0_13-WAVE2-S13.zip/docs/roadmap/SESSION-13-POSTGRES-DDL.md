# Session 13 — Postgres-backed DDL verification

**Date:** 2026-09-03
**Wave:** 2
**Scope:** apply every Wave 1 DDL statement to a real PostgreSQL instance via
`createSchema`, twice, and prove idempotency. No feature work.

## Environment actually used

| Component | Value |
| --- | --- |
| PostgreSQL | 17.9 (x86_64-pc-linux-gnu), local cluster, socket + 127.0.0.1:5433 |
| Node | v24.14.0 (matches `engines: >=24 <25`) |
| Install | `npm ci` in `backend/`, 41 packages |
| DATABASE_URL | `postgres://hope@127.0.0.1:5433/hope_s13` |

The sandbox refuses to run `initdb`/`postgres` as root; the cluster was created
and started under an unprivileged uid via `setpriv --reuid=1000`. Repeat that
step in any future session that needs Postgres in-sandbox.

## Deliverable

`backend/tests/postgres-bootstrap-integration.test.mjs` grew from 1 test to 3:

1. **bootstrap creates every mapped application table** (pre-existing; the
   hard-coded `assert.equal(rows.length, 22)` was wrong — the list holds 23
   table names, so the assertion is now taken from the list length).
2. **Wave 1 multi-vertical DDL applies and is idempotent** — asserts the
   `verticals` table and its seeded `jobs` row, `verticals.config` JSONB NOT
   NULL, `categories.vertical_id` UUID NULL, `jobs.vertical_id` UUID,
   `jobs.attributes` JSONB NOT NULL DEFAULT `'{}'::jsonb`, and the three Wave 1
   indexes `verticals_active_idx`, `categories_vertical_idx`,
   `jobs_vertical_idx`. `createSchema` is then run a **second** time and an
   `information_schema.columns` snapshot must be byte-identical, with the
   `jobs` seed still at exactly one row.
3. **backfills assign pre-existing rows** — inserts a category and a job with
   `vertical_id IS NULL` (i.e. rows that predate Wave 1), runs `createSchema`,
   and asserts both are assigned to the `jobs` vertical; a third run must not
   move them. The whole test runs in a transaction that is rolled back.

## Defects found by executing the DDL for the first time

Both were only observable against a real database and are fixed in this session.

1. **`src/db.js` `loadAll` ordered every mapped table by `created_at`.**
   `notification_preferences` has no such column (by design — `serialization.js`
   maps it to `updated_at`), so `initDatabase()` failed outright with
   `42703 column "created_at" does not exist`. Postgres bootstrap could never
   have worked. Fixed: the ORDER BY is now derived from `tableColumns[table]`
   and falls back to `id` when the table declares no `created_at`.
2. **`src/repository/core.js` job insert had 22 target columns but only 21
   placeholders** (`published_at` had no expression), so every
   `POST /api/v1/jobs` in Postgres mode returned 500 with
   `42601 INSERT has more target columns than expressions`. Fixed by adding
   `$22`; the values array already carried 22 entries.

## Verification — actual results

| Command | Result |
| --- | --- |
| `DATABASE_URL=... npm run test:postgres` (clean DB) | **3 tests / 3 pass / 0 fail / 0 skip**, exit 0 |
| `npm run test:offline` (no DATABASE_URL, post-fix) | **320 tests / 317 pass / 0 fail / 3 skipped**, exit 0 |
| `npm run check` | PASS |
| `DATABASE_URL=... npm run test:offline` (whole suite) | **290 tests / 271 pass / 19 fail / 0 skip**, exit 1 |

The 3 offline skips are exactly the 3 Postgres integration tests, which skip
without `DATABASE_URL`. The pre-session offline baseline was 318/317/0 fail/1
skip; the delta is the 2 tests added here.

## Honest limitation — acceptance only partially met

Session 13's stated acceptance was "`DATABASE_URL=... npm test` from `backend/`
with the skip count dropped to 0". The skip count **is** 0, but the suite does
not pass: 19 failures across 14 files. Those failures are **not** DDL failures
and are not caused by this session's two fixes — the offline suite is green
before and after. They are a previously unknown, separate problem:

- **The repository facade is incomplete in Postgres mode.** Every job-detail
  request fails with `repo.listOffersForJob is not a function`. The Postgres
  repository implements a subset of the collection-mode API.
- **The behavioural suites are not isolated per database.** They all share one
  database with no truncation between files, so state leaks across suites; in
  the full run even `postgres-bootstrap-integration` then fails, although it
  passes 3/3 in isolation against a clean database.

This is a genuine production risk — Postgres is the deployed persistence mode —
but repairing the runtime parity is a session of its own, not an opportunistic
add-on to a DDL verification session. It is filed as **Session 13B** in
`WAVE-2-SESSIONS.md` and recorded in STATE's open risks.

## Files touched

- `backend/tests/postgres-bootstrap-integration.test.mjs` (2 tests added, 1 wrong assertion corrected)
- `backend/src/db.js` (ORDER BY fallback)
- `backend/src/repository/core.js` (missing `$22` placeholder)
- `docs/roadmap/SESSION-13-POSTGRES-DDL.md` (this file)
- `docs/roadmap/WAVE-2-SESSIONS.md` (Session 13B appended)
- `docs/roadmap/SUPERPROMPT.md` (STATE)

No schema change, no route change, no payload change.
