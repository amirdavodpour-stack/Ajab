# Wave 1 — Session 9: Regression + Lint Promotion (executed)

Date: 2026-09-03
Toolchain used: Node.js **v24.14.0** (matches `backend/package.json` `engines: >=24 <25`),
Flutter **3.38.3** stable (obtained in-sandbox for the first time in Wave 1).

## 1. Backend full test suite — RUN FOR REAL

Command (from `backend/`): `npm ci` then `npm run test:offline`
(= `node --test --test-concurrency=1` over every `tests/*.test.mjs` except `s3-integration`).

### First run (baseline, before any change)
```
tests 318 | pass 315 | fail 2 | skipped 1 | duration 40.5s | exit 1
```

Failures (both real, both pre-existing, neither a Wave-1 multi-vertical regression):

1. `tests/mobile-taxonomy-contract.test.mjs` —
   `assert.match(create, /GET','\/categories/)`. The Dart sources were reformatted
   (trailing-comma / multi-line argument style) by the source-normalization pass, so
   the call is now `request('GET', '/categories')` with whitespace. The **contract still
   holds** (both `create_job_page.dart` and `jobs_page.dart` do call `GET /categories`
   and use `DropdownButtonFormField`); only the regex was formatting-brittle.
   **Fix applied:** regex relaxed to `/'GET'\s*,\s*'\/categories/` in both assertions.
   No application code touched.

2. `tests/release-validation-script.test.mjs` — `tools/release_candidate_check.sh`
   was not executable. Cause: the handoff ZIP does not carry POSIX permission bits, so
   **every** `*.sh` in the tree arrived as `0644`. This is a real release hazard: CI
   invokes these scripts directly.
   **Fix applied:** `chmod +x tools/*.sh backend/scripts/*.sh backend/entrypoint.sh
   backend/staging/providers/entrypoint.sh`.

### Final run (after the two fixes)
```
tests 318 | pass 317 | fail 0 | skipped 1 | duration 33.2s | exit 0
```
Skipped: `PostgreSQL bootstrap creates every mapped application table and can load state`
(`tests/postgres-bootstrap-integration.test.mjs`) — self-skips with no `DATABASE_URL`.
No Postgres server is available in this environment; the open risk from Session 2-4
(vertical DDL never executed against a real server) **remains open**.

Also run: `npm run check` (node --check on 6 entry modules) — PASS.
`npm audit` — NOT RUN: the sandbox npm registry mirror returns 404 for the audit
endpoint (`operation is not supported`). Supply-chain scanning must stay in GitHub CI.

## 2. Backend ESLint / Prettier — DOES NOT EXIST

Concrete finding, not a pass: there is **no** ESLint or Prettier configuration, and no
lint devDependency, anywhere in `backend/` (no `eslint.config.*`, `.eslintrc*`,
`.prettierrc*`; `package.json` has zero devDependencies). The `check` script is
`node --check` syntax validation only. Prior STATE entries describing "backend
ESLint/Prettier still never run" were describing tooling that was never actually added.

Decision: **not** bolting a linter on inside Session 9. Introducing ESLint means a config,
a devDependency, a CI gate and a first-run fix-up of ~40 source files — that is its own
deliverable. Scheduled explicitly as a Wave 2 session (see STATE `notes_for_future_sessions`).

## 3. Dart analyzer + `flutter test` — STILL NOT EXECUTED (hard blocker identified)

Progress vs previous sessions: a Flutter SDK **was** obtained this time
(`flutter 3.38.3 • stable`), so "no toolchain at all" is no longer the blocker.
Two concrete blockers were found instead:

1. **`pubspec.yaml` pins an unsatisfiable Flutter SDK constraint.**
   `environment: flutter: '>=3.47.0'` while the latest stable Flutter available is
   3.38.3, so `flutter pub get` aborts with
   `Because hope_mobile requires Flutter SDK version >=3.47.0, version solving failed.`
   A temporary relaxation to `>=3.24.0` was tested and **reverted** — the pin was not
   changed, because this session cannot verify which Flutter release the project is
   actually targeting, and silently loosening a version pin is exactly the kind of
   unverified assumption the plan forbids. This must be resolved deliberately in the
   dependency/toolchain session.

2. **pub.dev is unreachable from the sandbox.** With the constraint temporarily relaxed,
   `flutter pub get` fails with `Got TLS error trying to find package flutter_lints at
   https://pub.dev` on all 7 retries, despite `curl https://pub.dev/api/packages/http`
   returning 200 and `SSL_CERT_FILE`/`SSL_CERT_DIR` being set to the system bundle. The
   egress path terminates TLS in a way the Dart VM will not accept.

Consequence, stated plainly: **`dart analyze` and `flutter test` have never been executed
in Wave 1.** `test/job_vertical_model_test.dart` (written in Session 8) and every other
Dart test remain unexecuted. The analyzer stays advisory; it is **not** promoted, because
promoting a gate that has never been run once would be a fabricated result.
The Dart side is covered today only by the static contract tests in
`backend/tests/*-contract.test.mjs`, which read the `.dart` files as text — that is what
caught failure #1 above, and it is not a substitute for compilation.

## 4. Files changed in this session

- `backend/tests/mobile-taxonomy-contract.test.mjs` — 2 regexes made whitespace-tolerant.
- executable bit restored on 20 shell scripts (`tools/`, `backend/scripts/`, entrypoints).
- `docs/roadmap/SESSION-09-REGRESSION-REPORT.md` (this file).
- `docs/roadmap/SUPERPROMPT.md` — STATE block replaced.

No application source, no schema, no route, no Flutter widget was modified.
The jobs vertical is untouched.
