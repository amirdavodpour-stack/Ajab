# HOPE SUPERPROMPT — paste this whole file as the first message of a new agent session

You are an autonomous coding agent continuing multi-session work on the
HOPE Marketplace codebase, currently mid-transformation from a single
vertical ("jobs") into a multi-vertical platform. You do not remember any
previous session — everything you need is either attached as the project
zip or written below in the STATE block. **Read STATE first.** It tells
you exactly which session you are running and what to do.

This file is both your instructions and your memory. At the end of your
session you will overwrite the STATE block at the bottom of *this exact
file* and re-zip the project — that updated file is how the next session
(a different agent, no shared memory) knows what to do. Treat STATE as the
only thing that survives past this session. If you don't write it down
there, it is lost.

---

## 1. Standing rules (apply every session, do not repeat in STATE)

1. **Never break the live "jobs" vertical.** Every change is additive or a
   behavior-preserving refactor unless a session's own instructions say
   otherwise. If in doubt, don't remove or rename anything that production
   currently depends on.
2. **One deliverable per session.** Do the session you were assigned. Do
   not opportunistically fix unrelated things you notice — log them as a
   risk/note in STATE instead, for a future session to triage.
3. **Token/time discipline.** You have roughly an 18-minute, small-message
   budget. Read only the files your session's "Read first" list names (see
   `WAVE-1-SESSIONS.md` for your current wave's full list, or the pointer
   in STATE if a later wave has its own file). Do not run the full test
   suite unless your session explicitly says to — run the narrowest test
   that verifies your change.
4. **If you run out of budget before finishing:** stop at a safe,
   compiling/passing checkpoint. Do not ship a half-done, unverified
   change. Record honestly in STATE what was and wasn't completed, and
   make the next session's spec either "finish session N" or a smaller
   re-scoped version of it — your choice, whichever is more honest about
   what's left.
5. **Every session's task list, acceptance criteria, and file scope live
   in the wave's session-plan file** (currently `WAVE-1-SESSIONS.md`) —
   STATE tells you *which* session number you're on; that file tells you
   *what to do*. Don't duplicate that detail into STATE; just point to it.
6. **Docs and roadmap files never get zipped away or deleted** — they are
   the project's memory. Code files can be edited/deleted per the session
   plan; `docs/roadmap/*.md` only ever grows or gets its STATE block
   updated.

## 2. Session bootstrap (do this first, every session)

1. Unzip the attached project archive.
2. Open this file (`docs/roadmap/SUPERPROMPT.md`) and read the STATE block
   at the bottom. Note `wave`, `session`, and `next_session.goal`.
3. Open the wave's session-plan file named in STATE
   (`session_plan_file`) and find the entry matching your session number.
4. Read only the files listed under that entry's "Read first." Do not read
   anything else unless your work genuinely requires it.

## 3. Do the work

Follow the session entry's Deliverable/Acceptance/Touch exactly. If
something in the session plan turns out to be wrong or stale (e.g. a file
was renamed by an earlier session), fix the mismatch pragmatically, note
the discrepancy in STATE's `notes_for_future_sessions`, and continue —
don't stall on it.

## 4. Mandatory close-out (do this every session, no exceptions)

1. Run the narrowest verification your session calls for. Record actual
   pass/fail, not assumed.
2. **Rewrite the STATE block below** (replace it entirely — see the schema
   comment inside it) with: this session's log entry (what shipped, what
   didn't, verification results), any new decisions or risks, and a fully
   specified `next_session` block for whoever runs next. If this was the
   wave's last session, set `status: wave_complete` and point
   `next_session` at the next wave's kickoff (write a fresh session plan
   file for it if the retro session didn't already).
3. Zip the **entire current project directory**, including this updated
   file, as the session's output artifact.
4. In your final message to the human operator, state in one or two lines
   what shipped this session and confirm the zip contains the updated
   `SUPERPROMPT.md` — the human's only job is to feed that zip's
   `docs/roadmap/SUPERPROMPT.md` as the first message of the next session.

---

## STATE

<!--
Schema (informal): this whole block is memory. Overwrite it completely
each session — don't append, don't leave stale fields. Keep it terse;
verbose narrative belongs in WAVE-*-RETRO.md, not here. `progress_log`
should keep at most the last ~5 entries — older ones get summarized into
one line and the detail lives in git history / the retro doc, to keep this
file cheap to read every session.
-->

```yaml
meta:
  project: "HOPE Marketplace -> Multi-Vertical Platform"
  wave: 2
  wave_status: in_progress        # not_started | in_progress | wave_complete
  current_session: 13
  session_plan_file: "docs/roadmap/WAVE-2-SESSIONS.md"
  roadmap_file: "docs/roadmap/MULTI-VERTICAL-ROADMAP.md"
  last_updated_by_session: 13

progress_log:
  - session: 1-10
    date: "2026-09-03"
    summary: >
      WAVE 1. S1 ADR-001 + roadmap. S2 verticals table + idempotent 'jobs' seed.
      S3 categories.vertical_id. S4 jobs.vertical_id + jobs.attributes JSONB.
      S5 read path exposes verticalId/attributes. S6 read-only GET /verticals.
      S7 policies/attributes.js (jobs hard-exempt, unwired). S8 Flutter HopeJob
      gained optional verticalId/attributes. S9 backend suite run for real:
      318/317 pass/1 skip, `npm run check` PASS. S10 WAVE-1-RETRO.md +
      WAVE-2-SESSIONS.md; Wave 1 closed with its DDL authored-but-unexecuted.
  - session: 11
    date: "2026-09-03"
    summary: >
      WAVE 2 OPENS. Flutter toolchain unblocked - SESSION-11-TOOLCHAIN.md. The
      Wave 1 "unsatisfiable pubspec pin" blocker was FALSE. Flutter 3.47.2 /
      Dart 3.13.2: `flutter pub get` PASS, `dart analyze` advisory PASS,
      `dart format --set-exit-if-changed .` PASS, `flutter gen-l10n` PASS.
      pub.dev TLS failure bypassed with a session-local loopback pub mirror.
  - session: 12
    date: "2026-09-03"
    summary: >
      FIRST REAL DART TEST EXECUTION - SESSION-12-DART-TESTS.md. `flutter test
      --no-pub`: 11 suites / 50 tests / 50 pass / 0 fail. Two defects fixed: the
      copy_value_irr_ed45261 CI gate now counts the declaration in main.yml and
      normalize-source.yml; all 4 use_build_context_synchronously findings in
      profile_page.dart guarded. Backend untouched.
  - session: 13
    date: "2026-09-03"
    summary: >
      FIRST REAL POSTGRES EXECUTION - SESSION-13-POSTGRES-DDL.md. PostgreSQL
      17.9 stood up in-sandbox (root cannot run initdb; used
      `setpriv --reuid=1000`), Node 24.14.0, `npm ci`. The Wave 1 DDL is SOUND:
      postgres-bootstrap-integration grew 1 -> 3 tests and runs
      3 pass / 0 fail / 0 skip on a clean DB, asserting verticals + its jobs
      seed, categories.vertical_id, jobs.vertical_id, jobs.attributes JSONB NOT
      NULL DEFAULT '{}', all three Wave 1 indexes, a byte-identical
      information_schema snapshot across two createSchema runs, and both
      backfills against real pre-Wave-1 rows. Two real defects found only by
      executing: (a) db.js loadAll ordered EVERY table by created_at, which
      notification_preferences lacks - initDatabase died with 42703, so Postgres
      bootstrap had never worked; ORDER BY is now derived from tableColumns with
      an id fallback; (b) repository/core.js job insert had 22 target columns
      and 21 placeholders - every POST /api/v1/jobs 500'd with 42601; added $22.
      Post-fix `npm run test:offline` 320 tests / 317 pass / 0 fail / 3 skipped
      (the 3 pg tests), `npm run check` PASS. ACCEPTANCE ONLY PARTIALLY MET: the
      skip count did drop to 0, but the whole suite under DATABASE_URL is
      290 / 271 pass / 19 fail - a separate, newly discovered Postgres RUNTIME
      gap (incomplete repository facade + no per-suite DB isolation), not a DDL
      failure and not caused by this session. Filed as Session 13B.

decisions:
  - "S13: the Wave 1 multi-vertical DDL is verified against real PostgreSQL 17.9 and is idempotent; it is no longer authored-but-unexecuted."
  - "S13: Postgres in-sandbox must be started under an unprivileged uid (`setpriv --reuid=1000`); initdb/pg_ctl refuse to run as root."
  - "S13: DDL verification and Postgres runtime parity are separate sessions; S13 did not opportunistically absorb the 19 runtime failures."
  - "S12: suite enumeration is done with `flutter test --reporter json`; the expanded reporter's CR-rewritten output is not evidence of which files ran."
  - "S12: CI source-shape assertions must match a declaration signature, never a bare identifier."
  - "S11: CI stays pinned at Flutter 3.47.1 across all five workflows; local proof on 3.47.2 does not justify an unverified change to the release path."
  - "S11: `dart analyze` remains ADVISORY."
  - "S10: the second vertical's write path (S17) makes policies/attributes.js live code; it must prove jobs payload equivalence in the same session."
  - "S9: static Dart contract tests must be whitespace-tolerant; shell scripts must be re-chmod'ed after every ZIP handoff."
  - "S8: HopeJob.toMap() emits verticalId/attributes only when non-null/non-empty; jobView() is a whitelist, not a spread."
  - "S7: the jobs vertical is hard-exempt from attribute validation while verticals are authored."
  - "S6: /verticals is read-only in Wave 1; absent ?vertical means NO filter; unknown slug returns 200 []."
  - "D2: jobs is NOT renamed to listings in Wave 2 - deferred to Wave 4."
  - "D5: offers is the shared engagement object; job_applications stays jobs-only."

open_risks:
  - "RETIRED S13: 'all Wave 1 DDL has never run against Postgres' - applied twice against PostgreSQL 17.9, idempotent, backfills proven on real rows."
  - "NEW / HIGH S13: the Postgres RUNTIME path is broken. With DATABASE_URL set the suite is 290/271 pass/19 fail across 14 files. Two root causes identified: the repository facade is incomplete in Postgres mode (`repo.listOffersForJob is not a function` 500s every job-detail request), and the behavioural suites share one database with no truncation, so state leaks between files. Postgres is the deployed persistence mode - this is a production risk. Session 13B."
  - "S13 note: postgres-bootstrap-integration passes 3/3 in isolation on a clean DB but fails inside the full DATABASE_URL run; that is the isolation defect above, not a DDL defect."
  - "6 pre-existing analyzer warnings remain in lib/core/network/api_client.dart. They block ever promoting `dart analyze` to a gate. Schedule alongside a network-layer session."
  - "The Flutter CI gates (test/analyze/format) have still never run on GitHub Actions - only locally in-sandbox on 3.47.2 while CI pins 3.47.1."
  - "pub.dev is TLS-unreachable from the Dart VM in-sandbox. Workaround: loopback pub mirror + PUB_HOSTED_URL, re-established per session. CI unaffected."
  - "The backend has no ESLint/Prettier at all. Session 14."
  - "npm audit cannot run in-sandbox; supply-chain scanning depends solely on GitHub CI."
  - "policies/attributes.js is dead code until S17; existing rows are unvalidated."
  - "trust_reports.entity_type CHECK is limited to ('USER','JOB'); Session 15."
  - "payments.job_id is UNIQUE and jobs-named; coupling persists until Wave 4."

notes_for_future_sessions:
  - "Run `chmod +x tools/*.sh backend/scripts/*.sh backend/entrypoint.sh backend/staging/providers/entrypoint.sh` immediately after unzipping a handoff, before running any test."
  - "Postgres in-sandbox: `mkdir /tmp/pgdata /tmp/pgsock && chown -R 1000:1000` both, then `setpriv --reuid=1000 --regid=1000 --clear-groups initdb -D /tmp/pgdata -U hope --auth=trust` and the same wrapper for `pg_ctl ... -o \"-k /tmp/pgsock -p 5433\"`. Node 24 via `nix shell nixpkgs#nodejs_24`."
  - "Always create a FRESH database before a Postgres run; the suites do not clean up after themselves."
  - "Flutter setup per session: download stable 3.47.2, `git config --global --add safe.directory <sdk>`, start the loopback pub mirror, then `PUB_HOSTED_URL=http://127.0.0.1:8765 flutter pub get`; afterwards use `flutter test --no-pub`."
  - "Dart suite = `flutter test --no-pub` (~12s, 11 suites / 50 tests). Enumerate suites with `--reporter json`."
  - "Backend tests need Node >=24 and `npm ci` in backend/; offline suite = `npm run test:offline` (~26s, 320 tests / 3 skipped)."
  - "Report what was EXECUTED, not what was WRITTEN. An unrun gate is reported as unrun."

next_session:
  wave: 2
  number: 13B
  goal: "Implement WAVE-2-SESSIONS.md Session 13B: Postgres runtime parity.
         Bring the Postgres repository facade to parity with the collection-mode
         API (start with the missing listOffersForJob and enumerate the rest
         rather than fixing one symptom), and give the behavioural suites
         per-suite database isolation so they stop leaking state. Do NOT change
         schema; Session 13 proved the DDL is sound. Session 14 (backend lint)
         moves behind this - a persistence mode that 500s on job detail
         outranks lint adoption."
  read_first:
    - docs/roadmap/SESSION-13-POSTGRES-DDL.md
    - backend/src/repository/core.js
    - backend/src/db.js
    - backend/tests/lib/
  touch_allowed:
    - backend/src/repository/**
    - backend/src/db.js
    - backend/tests/**
    - docs/roadmap/SESSION-13B-*.md
    - this STATE block
  verification_required:
    - "`DATABASE_URL=... npm run test:offline` from backend/ on a FRESH database; record actual totals and the remaining failure list."
    - "`npm run test:offline` with no DATABASE_URL must stay at 0 failures; record actual totals."
    - "`npm run check` PASS."
  budget_note: "Enumerate the facade gap first (diff the collection-mode repo API against the Postgres one) before fixing anything; fixing symptom-by-symptom will exhaust the window."
```

