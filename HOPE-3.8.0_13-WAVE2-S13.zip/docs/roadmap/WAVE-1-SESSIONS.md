# Wave 1 — Session Plan (10 sessions)

> Reconstructed in Session 1: this file was missing from the baseline zip.
> Session 1's own entry is recorded as-executed; sessions 2-10 are specified
> from ADR-001 (`docs/architecture/ADR-001-multi-vertical.md`).
> Each session: one deliverable, narrow file scope, narrowest verification.

---

## Session 1 — ADR-001 (DONE)
- **Deliverable:** `docs/architecture/ADR-001-multi-vertical.md` mapping every
  real `jobs` / `categories` / `job_applications` column and deciding the
  multi-vertical model. No application code.
- **Read first:** roadmap, `backend/src/db/schema.js`,
  `docs/database/repository-sql.txt`, `backend/src/repository/core.js`.
- **Acceptance:** ADR exists, every current column classified, alternatives
  rejected with reasons.
- **Verification:** documentation review only.

## Session 2 — `verticals` table + jobs seed
- **Deliverable:** additive DDL in `createSchema`: `verticals` table, unique
  slug index, and an idempotent seed of the `jobs` vertical row.
- **Read first:** `backend/src/db/schema.js`, ADR-001 §4.
- **Touch:** `backend/src/db/schema.js` only.
- **Verification:** narrowest backend schema/bootstrap test.

## Session 3 — `vertical_id` on categories + backfill
- **Deliverable:** `categories.vertical_id` (nullable FK), backfill to jobs,
  `categories_vertical_idx`.
- **Touch:** `backend/src/db/schema.js`.
- **Verification:** categories repository test.

## Session 4 — `vertical_id` + `attributes` on jobs
- **Deliverable:** `jobs.vertical_id` (nullable FK, backfilled) and
  `jobs.attributes JSONB NOT NULL DEFAULT '{}'`, plus `jobs_vertical_idx`.
- **Touch:** `backend/src/db/schema.js`.
- **Verification:** jobs repository test — existing job payloads unchanged.

## Session 5 — Repository read path
- **Deliverable:** expose `verticalId` / `attributes` through
  `backend/src/repository/core.js` + `mappers.js` selects, defaulting so
  existing responses are byte-compatible.
- **Verification:** jobs mapper/repository tests.

## Session 6 — Vertical registry service + API
- **Deliverable:** read-only `GET /verticals`, vertical-scoped categories query
  (defaults to jobs when no vertical is supplied).
- **Verification:** route test for both the scoped and the default path.

## Session 7 — Attribute schema validation helper
- **Deliverable:** server-side validator reading `verticals.config`, applied
  only to non-jobs verticals.
- **Verification:** unit test for valid / invalid attribute payloads.

## Session 8 — Client-side model plumbing (Flutter, additive)
- **Deliverable:** optional `verticalId` / `attributes` on the listing model +
  JSON round-trip; no UI change.
- **Verification:** targeted Dart model test.

## Session 9 — Regression + lint promotion
- **Deliverable:** run backend ESLint/Prettier and the tightened Dart analyzer
  for real; either promote out of advisory mode or log concrete findings.
  Full backend test suite is in scope for this session only.
- **Verification:** recorded actual pass/fail counts.

## Session 10 — Wave 1 retro + Wave 2 plan
- **Deliverable:** `docs/roadmap/WAVE-1-RETRO.md` and
  `docs/roadmap/WAVE-2-SESSIONS.md`; set `wave_status: wave_complete` in the
  SUPERPROMPT STATE block.
