# Session 11 — Flutter Toolchain Unblock (Wave 2)

Date: 2026-09-03
Scope: toolchain only. No feature, schema, route or widget code was changed.

## Result: the Wave 1 "HARD BLOCKER" was FALSE

Wave 1 / Session 9 recorded that `pubspec.yaml`'s `flutter: '>=3.47.0'`
constraint was unsatisfiable because "the newest obtainable stable is 3.38.3".
That was wrong. The live release index
(`https://storage.googleapis.com/flutter_infra_release/releases/releases_linux.json`)
reports current stable **3.47.2** (2026-08-27), with 3.47.1 and 3.47.0 also
published. The pin is satisfiable and CI's existing `FLUTTER_VERSION: '3.47.1'`
is a valid stable release.

## What was actually executed this session

Toolchain acquired in-session: Flutter **3.47.2** stable
(revision d3b14c8769, Dart **3.13.2**, DevTools 2.60.0), Linux x64.

| Command | Result |
|---|---|
| `flutter --version` | Flutter 3.47.2 / Dart 3.13.2 — PASS |
| `flutter pub get` | **PASS** — 89 dependencies resolved, `pubspec.lock` unchanged (md5 `a23600b48ca863eb0568c594b5253d7d`) |
| `dart analyze` | **PASS (advisory)** — 0 errors, 0 warnings, **59 info-level lints** |
| `dart format --set-exit-if-changed .` | **PASS** — 50 files, 0 changed |
| `flutter gen-l10n` | **PASS** — regenerates `lib/l10n/generated/*` with no source drift |
| `flutter test` | **NOT RUN** — reserved for Session 12, which owns first Dart test execution |

`pubspec.lock` is byte-identical after resolution: the locked graph was already
correct, so nothing is committed from the resolve.

## pub.dev TLS: real, and now worked around

The Dart VM still fails against pub.dev directly:
`HandshakeException ... CERTIFICATE_VERIFY_FAILED: unable to get local issuer
certificate`. `curl` succeeds with the sandbox bundle
(`/etc/ssl/certs/ca-bundle.crt`), and setting `SSL_CERT_FILE` / `SSL_CERT_DIR`
does **not** fix the Dart client — the egress proxy's CA is not in the VM's
built-in BoringSSL root set.

Workaround used (session-local only, nothing committed): a loopback HTTP
mirror of pub.dev on `127.0.0.1:8791` that rewrites `https://pub.dev` inside
JSON API responses, driven by `PUB_HOSTED_URL`. This is a *sandbox* aid, not a
project artifact. GitHub CI has direct pub.dev access and needs none of it.

## Analyzer posture (unchanged)

`dart analyze` is **advisory** this session and is NOT promoted to a gate,
per the Session 9 decision. The 59 findings are all `info`:

- `curly_braces_in_flow_control_structures` (~30) — admin, auth, notifications,
  transactions, job detail
- `prefer_const_constructors` / `prefer_const_literals_to_create_immutables` (~7)
- `unnecessary_string_interpolations`, `unnecessary_brace_in_string_interps` (4)
- `use_build_context_synchronously` (4, all `lib/features/profile/profile_page.dart`)

The `use_build_context_synchronously` findings are the only ones with runtime
significance; they are scheduled, not fixed here.

## Finding to schedule (not fixed in this session)

`.github/workflows/main.yml` "Flutter dependency and generated-code gate"
asserts `grep -Roh 'copy_value_irr_ed45261' lib/core/ui/hope_l10n.dart | wc -l`
equals **1**, but the current source contains **2** matching lines
(`hope_l10n.dart:408-409`). As written, that gate fails on the current tree.
Recorded as an open risk for Session 12; not touched here to keep this session
single-deliverable.

## Decision

Keep `flutter: '>=3.47.0'` and keep CI pinned at `3.47.1` across all workflows.
Resolution is proven on 3.47.2 locally and 3.47.1 is a published stable that
satisfies the same constraint; bumping five workflow files buys nothing and
would be an unverified change to the release path.
