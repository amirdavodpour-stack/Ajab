# HOPE 3.8.0+11 — APK build notes (2026-09-02)

## Source changes in this package

1. Generated `pubspec.lock` with Flutter 3.47.1 / Dart 3.13.1.
2. Canonical `dart format` across Dart sources.
3. Compile-blocking missing imports:
   - `lib/features/marketplace/job_detail_page.dart` now imports `copy.dart` (`moneyLabel`).
   - `lib/features/profile/profile_page.dart` now imports `api_error_presenter.dart` (`apiErrorMessage`).
4. `flutter analyze` has **0 errors** after those imports. Remaining lints are info/warning only.

## Pilot APK produced in this session

- Profile: `pilot` (debug-keystore signed, not Play Store / production).
- Package: `com.hope.marketplace`
- versionName `3.8.0` / versionCode `11`
- ABI: `android-arm64` (Android 11+ / minSdk 30).
- `API_BASE_URL` baked into the APK: `https://hope.example.com/api/v1`
  Replace this at rebuild time with your real HTTPS API.

Production signing still requires `ANDROID_RELEASE_STORE_FILE` and related secrets.

## Rebuild

```bash
export ANDROID_HOME=/path/to/android-sdk
export JAVA_HOME=/path/to/jdk-17
flutter pub get
BUILD_PROFILE=pilot flutter build apk --release \
  --target-platform android-arm64 \
  --dart-define=API_BASE_URL=https://YOUR-API/api/v1
```
