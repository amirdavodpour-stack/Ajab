# HOPE 3.8.0+11 — CI Audit Baseline (2026-09-02)

This file records evidence available before the V6 packaging changes. It is intentionally not a claim of production readiness.

## Verified baseline facts

- Flutter baseline: 3.47.0
- Dart expected by Flutter 3.47.0: 3.13.0
- Java baseline for V6 CI: 17
- Android package: `com.hope.marketplace`
- versionName: `3.8.0`
- versionCode: `11`
- Pilot profile: `pilot`
- Existing GitHub diagnostic evidence showed a real release compilation failure caused by `IntegrationTestPlugin` / `GeneratedPluginRegistrant.java` mismatch.
- Existing GitHub diagnostic evidence also showed a Flutter test failure involving `shared_preferences` platform access in `test/upload_queue_test.dart`.
- Existing GitHub diagnostic evidence showed APK output-path/discovery mismatch between Gradle output and Flutter CLI discovery.

## Static score evidence

The repository score engine was run without editing its scoring model.

- `minScore`: **78**
- `allAtLeast90`: **false**
- Below 90:
  - `storage`: 88
  - `notifications_outbox`: 88
  - `mobile_flutter`: 78
  - `performance`: 84
  - `disaster_recovery_resilience`: 88
  - `production_readiness`: 79

## V6 response

V6 addresses the known CI/build-path issues by:

1. making Gradle `:app:assembleRelease` the Android release build source of truth;
2. discovering APKs independently of Flutter CLI artifact-path assumptions;
3. verifying package/version/size/signature/SHA-256 before artifact upload;
4. isolating `integration_test` in a disposable release copy;
5. initializing `shared_preferences` test state deterministically;
6. making the pilot quality gate fail on format/analyze/test failures;
7. aligning Android-capable CI jobs to Java 17.

The V6 package does **not** claim that the 950/1000 target has been reached. Full CI/runtime/backend evidence must still be obtained after upload and execution in GitHub Actions.
