import 'package:flutter/material.dart';
import '../../core/ui/hope_l10n.dart';
import 'package:provider/provider.dart';
import '../../core/auth/auth_controller.dart';
import '../../core/network/api_client.dart';
import '../../core/settings/settings_controller.dart';
import '../../core/ui/brand.dart';
import '../../core/ui/components.dart';
import '../../theme/app_theme.dart';
import '../admin/admin_page.dart';
import '../auth/login_page.dart';
import '../auth/register_page.dart';
import '../jobs/jobs_page.dart';
import '../notifications/notifications_page.dart';
import '../marketplace/create_job_page.dart';
import '../profile/profile_page.dart';
import '../transactions/transactions_page.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key, required this.api});
  final ApiClient api;
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  int tab = 0;
  late final List<Widget?> _tabs = List<Widget?>.filled(5, null);
  Widget _buildTab(int index) => _tabs[index] ??= switch (index) {
        0 => _HomeFeed(api: widget.api, onOpenExplore: () => _selectTab(1)),
        1 => JobsPage(key: const ValueKey('explore'), api: widget.api),
        2 => TransactionsPage(
            key: const ValueKey('transactions'), api: widget.api),
        3 => ProfilePage(key: const ValueKey('profile'), api: widget.api),
        4 => const SizedBox.shrink(),
        _ => const SizedBox.shrink(),
      };

  void _selectTab(int value) {
    if (value == tab) return;
    setState(() => tab = value);
  }

  @override
  Widget build(BuildContext context) {
    final auth = context.watch<AuthController>();
    final settings = context.watch<HopeSettingsController>();
    final isEn = Localizations.localeOf(context).languageCode == 'en';
    return Scaffold(
      body: SafeArea(
          child: IndexedStack(
              index: tab,
              children: List.generate(
                  4,
                  (i) =>
                      _tabs[i] ??
                      (i == tab ? _buildTab(tab) : const SizedBox.shrink())))),
      floatingActionButton: tab == 0
          ? FloatingActionButton.extended(
              onPressed: () => _openCreate(context),
              icon: const Icon(Icons.add_rounded),
              label: Text(HopeCopy.of(context).copy_post_opportunity_0389bce),
            )
          : null,
      bottomNavigationBar: NavigationBar(
        selectedIndex: tab,
        onDestinationSelected: _selectTab,
        destinations: [
          NavigationDestination(
              icon: const Icon(Icons.home_outlined),
              selectedIcon: const Icon(Icons.home_rounded),
              label: HopeCopy.of(context).copy_home_ce76258),
          NavigationDestination(
              icon: const Icon(Icons.explore_outlined),
              selectedIcon: const Icon(Icons.explore_rounded),
              label: HopeCopy.of(context).copy_explore_115e9fd),
          NavigationDestination(
              icon: const Icon(Icons.swap_horiz_rounded),
              selectedIcon: const Icon(Icons.swap_horizontal_circle_rounded),
              label: HopeCopy.of(context).copy_activity_4b38716),
          NavigationDestination(
              icon: const Icon(Icons.person_outline_rounded),
              selectedIcon: const Icon(Icons.person_rounded),
              label: HopeCopy.of(context).copy_profile_8b081d3),
        ],
      ),
      drawer: Drawer(
          child: SafeArea(
              child: ListView(padding: const EdgeInsets.all(16), children: [
        const HopeMark(size: 48),
        const SizedBox(height: 18),
        Text(HopeCopy.of(context).copy_your_professional_path_2da0026,
            style: Theme.of(context).textTheme.headlineSmall),
        const SizedBox(height: 6),
        Text(
            HopeCopy.of(context)
                .copy_find_the_right_opportunity_or_create_one_c8a9e6f,
            style: Theme.of(context).textTheme.bodyMedium),
        const SizedBox(height: 20),
        _drawerTile(context, Icons.explore_rounded,
            HopeCopy.of(context).copy_explore_missions_jobs_3846ebd, () {
          Navigator.pop(context);
          _selectTab(1);
        }),
        _drawerTile(context, Icons.add_business_rounded,
            HopeCopy.of(context).copy_post_a_mission_or_job_364fb6f, () {
          Navigator.pop(context);
          _openCreate(context);
        }),
        if (!auth.isGuest)
          _drawerTile(context, Icons.notifications_rounded,
              HopeCopy.of(context).copy_notifications_370b4a1, () {
            Navigator.pop(context);
            Navigator.push(
                context,
                MaterialPageRoute(
                    builder: (_) => NotificationsPage(api: widget.api)));
          }),
        if (auth.user?['role'] == 'ADMIN')
          _drawerTile(context, Icons.admin_panel_settings_rounded,
              HopeCopy.of(context).copy_admin_panel_348cd94, () {
            Navigator.pop(context);
            Navigator.push(context,
                MaterialPageRoute(builder: (_) => AdminPage(api: widget.api)));
          }),
        const Divider(height: 26),
        ListTile(
            leading: const HopeIconTile(Icons.location_on_outlined),
            title: Text(HopeCopy.of(context).copy_current_location_182622a),
            subtitle: Text(settings.city),
            onTap: () {
              Navigator.pop(context);
              _selectTab(3);
            }),
        ListTile(
            leading: const HopeIconTile(Icons.translate_rounded),
            title: Text((isEn
                ? HopeCopy.of(context).copy_language_english_d9f5a4a
                : HopeCopy.of(context).copy_language_persian_3ffcd3e)),
            onTap: () async {
              await settings
                  .setLanguage(settings.language == 'fa' ? 'en' : 'fa');
              if (mounted) setState(() {});
            }),
      ]))),
    );
  }

  Widget _drawerTile(BuildContext context, IconData icon, String label,
          VoidCallback tap) =>
      ListTile(
          leading: HopeIconTile(icon, filled: true, size: 42),
          title:
              Text(label, style: const TextStyle(fontWeight: FontWeight.w800)),
          onTap: tap);

  void _openCreate(BuildContext context) {
    final auth = context.read<AuthController>();
    if (auth.isGuest) {
      _showSignIn(context, widget.api);
      return;
    }
    Navigator.push(context,
        MaterialPageRoute(builder: (_) => CreateJobPage(api: widget.api)));
  }
}

void _showSignIn(BuildContext context, ApiClient api) {
  showModalBottomSheet<void>(
      context: context,
      showDragHandle: true,
      isScrollControlled: true,
      builder: (sheetContext) => SafeArea(
          child: Padding(
              padding: const EdgeInsets.fromLTRB(22, 6, 22, 28),
              child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    const HopeMark(size: 48),
                    const SizedBox(height: 16),
                    Text(HopeCopy.of(context).copy_start_here_555e56f,
                        style: Theme.of(context).textTheme.headlineSmall),
                    const SizedBox(height: 7),
                    Text(
                        HopeCopy.of(context)
                            .copy_create_an_account_or_log_in_to_post_opport_6bc74a1,
                        style: Theme.of(context).textTheme.bodyMedium),
                    const SizedBox(height: 18),
                    FilledButton.icon(
                        onPressed: () {
                          Navigator.pop(sheetContext);
                          Navigator.push(
                              context,
                              MaterialPageRoute(
                                  builder: (_) => RegisterPage(api: api)));
                        },
                        icon: const Icon(Icons.person_add_alt_1_rounded),
                        label: Text(
                            HopeCopy.of(context).copy_create_account_bfa3517)),
                    const SizedBox(height: 9),
                    OutlinedButton.icon(
                        onPressed: () {
                          Navigator.pop(sheetContext);
                          Navigator.push(
                              context,
                              MaterialPageRoute(
                                  builder: (_) => LoginPage(api: api)));
                        },
                        icon: const Icon(Icons.login_rounded),
                        label: Text(HopeCopy.of(context).copy_log_in_b4c960b)),
                  ]))));
}

class _HomeFeed extends StatelessWidget {
  const _HomeFeed({required this.api, required this.onOpenExplore});
  final ApiClient api;
  final VoidCallback onOpenExplore;

  @override
  Widget build(BuildContext context) {
    final auth = context.watch<AuthController>();
    final settings = context.watch<HopeSettingsController>();
    final name = auth.isGuest
        ? HopeCopy.of(context).copy_hope_friend_b997e02
        : '${auth.user?['displayName'] ?? HopeCopy.of(context).copy_hope_friend_b997e02}';
    return HopeResponsive(
        child: ListView(
            padding: const EdgeInsets.fromLTRB(0, 16, 0, 122),
            children: [
          Row(children: [
            const Expanded(child: HopeMark()),
            IconButton(
                onPressed: () => Scaffold.of(context).openDrawer(),
                icon: const Icon(Icons.menu_rounded),
                tooltip: HopeCopy.of(context).copy_menu_1f381a4)
          ]),
          const SizedBox(height: 24),
          Text('${HopeCopy.of(context).copy_hello_fc7ef4a} $name 👋',
              style: Theme.of(context).textTheme.displaySmall),
          const SizedBox(height: 6),
          Text(
              HopeCopy.of(context)
                  .copy_a_clearer_more_human_way_to_find_work_3553ab8,
              style: Theme.of(context).textTheme.bodyLarge),
          const SizedBox(height: 18),
          _VisualHero(context,
              settings: settings, onOpenExplore: onOpenExplore),
          const SizedBox(height: 20),
          Row(children: [
            Expanded(
                child: _BigAction(
                    icon: Icons.bolt_rounded,
                    title: HopeCopy.of(context).copy_missions_a833d13,
                    text: HopeCopy.of(context)
                        .copy_defined_tasks_with_clear_pay_9120d5e,
                    color: AppColors.primary,
                    onTap: onOpenExplore)),
            const SizedBox(width: 10),
            Expanded(
                child: _BigAction(
                    icon: Icons.business_center_rounded,
                    title: HopeCopy.of(context).copy_jobs_ebf9a80,
                    text: HopeCopy.of(context)
                        .copy_part_time_or_full_time_a007875,
                    color: AppColors.secondary,
                    onTap: onOpenExplore))
          ]),
          const SizedBox(height: 22),
          SectionTitle(
              title: HopeCopy.of(context).copy_recommended_for_you_e56d06b,
              subtitle: HopeCopy.of(context)
                  .copy_based_on_your_city_and_preferences_79e2a31),
          const SizedBox(height: 11),
          _RecommendationCard(context, settings.city),
          const SizedBox(height: 20),
          HopeSurface(
              padding: const EdgeInsets.all(18),
              child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(HopeCopy.of(context).copy_how_hope_works_bea7074,
                        style: Theme.of(context).textTheme.titleLarge),
                    const SizedBox(height: 12),
                    _step(
                        context,
                        '۱',
                        HopeCopy.of(context).copy_choose_79a9d79,
                        HopeCopy.of(context)
                            .copy_decide_whether_you_want_a_mission_or_a_job_3a6f9b5),
                    _step(
                        context,
                        '۲',
                        HopeCopy.of(context).copy_explore_837e4eb,
                        HopeCopy.of(context)
                            .copy_filter_by_city_field_and_opportunity_type_1d75340),
                    _step(
                        context,
                        '۳',
                        HopeCopy.of(context).copy_apply_1b61105,
                        HopeCopy.of(context)
                            .copy_apply_with_a_strong_professional_profile_13980b1),
                  ])),
        ]));
  }

  Widget _step(BuildContext context, String n, String title, String text) =>
      Padding(
          padding: const EdgeInsets.symmetric(vertical: 6),
          child: Row(children: [
            Container(
                width: 31,
                height: 31,
                alignment: Alignment.center,
                decoration: BoxDecoration(
                    color: AppColors.primary.withValues(alpha: .1),
                    shape: BoxShape.circle),
                child: Text(n,
                    style: const TextStyle(
                        fontWeight: FontWeight.w900,
                        color: AppColors.primary))),
            const SizedBox(width: 10),
            Expanded(
                child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                  Text(title, style: Theme.of(context).textTheme.titleMedium),
                  Text(text, style: Theme.of(context).textTheme.bodyMedium)
                ]))
          ]));
}

class _VisualHero extends StatelessWidget {
  const _VisualHero(this.context,
      {required this.settings, required this.onOpenExplore});
  final BuildContext context;
  final HopeSettingsController settings;
  final VoidCallback onOpenExplore;
  @override
  Widget build(BuildContext context) => ClipRRect(
      borderRadius: BorderRadius.circular(30),
      child: SizedBox(
          height: 250,
          child: Stack(fit: StackFit.expand, children: [
            Image.asset('assets/images/hope_marketplace_hero.png',
                fit: BoxFit.cover),
            DecoratedBox(
                decoration: BoxDecoration(
                    gradient: LinearGradient(
                        begin: Alignment.topCenter,
                        end: Alignment.bottomCenter,
                        colors: [
                  Colors.black.withValues(alpha: .05),
                  Colors.black.withValues(alpha: .74)
                ]))),
            Padding(
              padding: const EdgeInsets.all(20),
              child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    SoftPill(
                        icon: Icons.location_on_rounded,
                        label: settings.city,
                        color: Colors.white),
                    const Spacer(),
                    Text(
                        HopeCopy.of(context)
                            .copy_opportunities_may_already_be_nearby_585bbac,
                        style: const TextStyle(
                            color: Colors.white,
                            fontSize: 24,
                            height: 1.08,
                            fontWeight: FontWeight.w900)),
                    const SizedBox(height: 7),
                    Text(
                        HopeCopy.of(context)
                            .copy_start_with_your_city_or_explore_any_other__05a1e84,
                        style: const TextStyle(
                            color: Colors.white70, height: 1.45)),
                    const SizedBox(height: 14),
                    SizedBox(
                        width: 150,
                        child: FilledButton(
                            onPressed: onOpenExplore,
                            style: FilledButton.styleFrom(
                                backgroundColor: Colors.white,
                                foregroundColor: AppColors.primary),
                            child: Text(
                                HopeCopy.of(context).copy_explore_a80d678))),
                  ]),
            ),
          ])));
}

class _BigAction extends StatelessWidget {
  const _BigAction(
      {required this.icon,
      required this.title,
      required this.text,
      required this.color,
      required this.onTap});
  final IconData icon;
  final String title;
  final String text;
  final Color color;
  final VoidCallback onTap;
  @override
  Widget build(BuildContext context) => PressableScale(
      onTap: onTap,
      semanticLabel: '$title. $text',
      child: HopeSurface(
          highlight: true,
          padding: const EdgeInsets.all(16),
          child: Row(children: [
            HopeIconTile(icon, filled: true, color: color, size: 48),
            const SizedBox(width: 11),
            Expanded(
                child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                  Text(title, style: Theme.of(context).textTheme.titleMedium),
                  const SizedBox(height: 3),
                  Text(text, style: Theme.of(context).textTheme.bodyMedium)
                ]))
          ])));
}

class _RecommendationCard extends StatelessWidget {
  const _RecommendationCard(this.context, this.city);
  final BuildContext context;
  final String city;
  @override
  Widget build(BuildContext context) => HopeSurface(
      padding: const EdgeInsets.all(16),
      child: Row(children: [
        HopeIconTile(Icons.near_me_rounded,
            filled: true, color: AppColors.secondary, size: 48),
        const SizedBox(width: 12),
        Expanded(
            child:
                Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(HopeCopy.of(context).copy_opportunities_near_9da643a,
              style: Theme.of(context).textTheme.bodyMedium),
          Text(city, style: Theme.of(context).textTheme.titleMedium),
          const SizedBox(height: 3),
          Text(
              HopeCopy.of(context)
                  .copy_location_personalization_is_on_you_can_cha_8dd12f4,
              style: Theme.of(context).textTheme.bodyMedium)
        ]))
      ]));
}
