import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../core/marketplace/category.dart';
import '../../core/network/api_client.dart';
import '../../core/network/api_error_presenter.dart';
import '../../core/settings/settings_controller.dart';
import '../../core/ui/components.dart';
import '../../core/ui/hope_l10n.dart';
import 'create_job_validator.dart';

import '../../theme/app_theme.dart';

class CreateJobPage extends StatefulWidget {
  const CreateJobPage({super.key, required this.api});

  final ApiClient api;

  @override
  State<CreateJobPage> createState() => _CreateJobPageState();
}

class _CreateJobPageState extends State<CreateJobPage> {
  final title = TextEditingController();
  final desc = TextEditingController();
  final min = TextEditingController();
  final max = TextEditingController();
  final duration = TextEditingController(text: '8');
  final salary = TextEditingController();
  final deadline = TextEditingController();
  final accept = TextEditingController();

  bool busy = false;
  String kind = 'MISSION';
  String visibility = 'PUBLIC';
  String schedule = 'FULL_TIME';
  String city = '';
  String? categoryId;

  late Future<List<HopeCategory>> _categoriesFuture;

  @override
  void initState() {
    super.initState();
    city = context.read<HopeSettingsController>().city;
    _categoriesFuture = _loadCategories();
  }

  Future<List<HopeCategory>> _loadCategories() async {
    final raw = await widget.api.request('GET', '/categories');
    final list = raw is List
        ? raw
        : raw is Map && raw['data'] is List
            ? raw['data']
            : const [];

    final categories = list
        .whereType<Map>()
        .map((m) => HopeCategory.fromMap(Map<String, dynamic>.from(m)))
        .toList();

    return flattenCategories(categories);
  }

  @override
  void dispose() {
    for (final controller in [
      title,
      desc,
      min,
      max,
      duration,
      salary,
      deadline,
      accept,
    ]) {
      controller.dispose();
    }
    super.dispose();
  }

  Future<void> submit() async {
    final effectiveMin = kind == 'JOB' ? salary.text : min.text;
    final effectiveMax = kind == 'JOB' ? salary.text : max.text;
    final selectedCategory = categoryId;

    if (selectedCategory == null || selectedCategory.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            HopeCopy.of(context).copy_choose_a_professional_category_b4cf5b8,
          ),
        ),
      );
      return;
    }

    final validation = validateCreateJob(
      title: title.text,
      description: desc.text,
      categoryId: selectedCategory,
      minBudget: effectiveMin,
      maxBudget: effectiveMax,
      duration: kind == 'JOB' ? '30' : duration.text,
      acceptanceCriteria: accept.text.trim().isEmpty
          ? HopeCopy.of(context).copy_as_described_in_the_opportunity_836cb3e
          : accept.text,
    );

    if (!validation.isValid) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(validation.error!)),
      );
      return;
    }

    if (kind == 'JOB' && deadline.text.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            HopeCopy.of(context)
                .copy_set_an_application_deadline_for_jobs_5fd80f8,
          ),
        ),
      );
      return;
    }

    setState(() => busy = true);

    try {
      final body = <String, dynamic>{
        'title': title.text.trim(),
        'description': desc.text.trim(),
        'categoryId': selectedCategory,
        'jobType': kind == 'MISSION' ? 'FIXED' : 'HOURLY',
        'budgetType': 'FIXED',
        'budgetMin': double.parse(effectiveMin.trim()),
        'budgetMax': double.parse(effectiveMax.trim()),
        'duration': kind == 'JOB' ? 30 : int.parse(duration.text.trim()),
        'acceptanceCriteria': accept.text.trim().isEmpty
            ? HopeCopy.of(context).copy_as_described_in_the_opportunity_836cb3e
            : accept.text.trim(),
        'city': city.trim().isEmpty
            ? context.read<HopeSettingsController>().city
            : city.trim(),
        'kind': kind,
        'visibility': visibility,
        'schedule': kind == 'JOB' ? schedule : null,
        'monthlySalary':
            kind == 'JOB' ? double.parse(salary.text.trim()) : null,
        'applicationDeadline': kind == 'JOB' ? deadline.text.trim() : null,
      };

      final data = await widget.api.request(
        'POST',
        '/jobs',
        auth: true,
        body: body,
      );

      final id = data is Map ? data['id'] : null;
      if (id == null) {
        throw const FormatException('Missing opportunity id');
      }

      await widget.api.request(
        'POST',
        '/jobs/$id/publish',
        auth: true,
      );

      if (!mounted) return;

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            HopeCopy.of(context).copy_opportunity_published_81a9fd1,
          ),
        ),
      );
      Navigator.pop(context);
    } catch (error) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
            content: Text(apiErrorMessage(error,
                fallback: HopeCopy.of(context)
                    .copy_the_server_did_not_return_data_try_again_bccfbb3))),
      );
    } finally {
      if (mounted) {
        setState(() => busy = false);
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final isEn = Localizations.localeOf(context).languageCode == 'en';

    return Scaffold(
      appBar: AppBar(
        title: Text(
          HopeCopy.of(context).copy_post_a_new_opportunity_f7fe3d9,
        ),
      ),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(20, 6, 20, 40),
        children: [
          _TypeHero(
            kind: kind,
            onChanged: (value) => setState(() => kind = value),
          ),
          const SizedBox(height: 18),
          SectionTitle(
            title: HopeCopy.of(context).copy_audience_visibility_5a0ddcb,
            subtitle:
                HopeCopy.of(context).copy_make_it_public_or_specialized_e890215,
          ),
          const SizedBox(height: 10),
          Row(
            children: [
              Expanded(
                child: _selectCard(
                  context,
                  Icons.public_rounded,
                  HopeCopy.of(context).copy_public_21e97be,
                  HopeCopy.of(context).copy_for_everyone_ebc769c,
                  'PUBLIC',
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: _selectCard(
                  context,
                  Icons.auto_awesome_rounded,
                  HopeCopy.of(context).copy_specialized_5d1ca04,
                  HopeCopy.of(context).copy_for_a_specific_field_9b79bd6,
                  'SPECIALIZED',
                ),
              ),
            ],
          ),
          const SizedBox(height: 20),
          HopeSurface(
            padding: const EdgeInsets.all(16),
            child: Column(
              children: [
                TextField(
                  controller: title,
                  decoration: InputDecoration(
                    labelText: HopeCopy.of(context).copy_title_d4694a2,
                    prefixIcon: const Icon(Icons.title_rounded),
                  ),
                ),
                const SizedBox(height: 11),
                TextField(
                  controller: desc,
                  maxLines: 5,
                  decoration: InputDecoration(
                    labelText:
                        HopeCopy.of(context).copy_full_description_c4dea43,
                    alignLabelWithHint: true,
                    prefixIcon: const Icon(Icons.notes_rounded),
                  ),
                ),
                const SizedBox(height: 11),
                FutureBuilder<List<HopeCategory>>(
                  future: _categoriesFuture,
                  builder: (context, snapshot) {
                    final categories = snapshot.data ?? const <HopeCategory>[];
                    return DropdownButtonFormField<String>(
                      initialValue: categoryId,
                      decoration: InputDecoration(
                        labelText: HopeCopy.of(context)
                            .copy_professional_category_a8c7c42,
                        hintText:
                            HopeCopy.of(context).copy_choose_a_category_b77d860,
                        prefixIcon: const Icon(Icons.category_outlined),
                      ),
                      items: categories.map((category) {
                        final depth = category.parentId == null ? 0 : 1;
                        return DropdownMenuItem<String>(
                          value: category.slug,
                          child: Text(
                            '${depth == 0 ? '' : '  ↳ '}${category.label(isEn)}',
                          ),
                        );
                      }).toList(),
                      onChanged: (value) => setState(() => categoryId = value),
                    );
                  },
                ),
                const SizedBox(height: 11),
                DropdownButtonFormField<String>(
                  initialValue: city,
                  decoration: InputDecoration(
                    labelText: HopeCopy.of(context).copy_city_3d7dc3e,
                    prefixIcon: const Icon(Icons.location_on_outlined),
                  ),
                  items: [
                    ...HopeSettingsController.cities.map(
                      (value) => DropdownMenuItem<String>(
                        value: value,
                        child: Text(value),
                      ),
                    ),
                  ],
                  onChanged: (value) => setState(() => city = value ?? city),
                ),
              ],
            ),
          ),
          const SizedBox(height: 20),
          SectionTitle(
            title: kind == 'MISSION'
                ? HopeCopy.of(context).copy_price_time_4d31a36
                : HopeCopy.of(context).copy_salary_schedule_bab0cb3,
            subtitle: kind == 'MISSION'
                ? HopeCopy.of(context)
                    .copy_set_a_defined_price_and_delivery_time_1e53f1a
                : HopeCopy.of(context)
                    .copy_the_first_month_salary_determines_hope_s_j_ca73bd3,
          ),
          const SizedBox(height: 10),
          if (kind == 'MISSION')
            Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: min,
                    keyboardType: TextInputType.number,
                    decoration: InputDecoration(
                      labelText: HopeCopy.of(context).copy_minimum_pay_38cc5ec,
                      prefixIcon: const Icon(Icons.payments_outlined),
                    ),
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: TextField(
                    controller: max,
                    keyboardType: TextInputType.number,
                    decoration: InputDecoration(
                      labelText: HopeCopy.of(context).copy_maximum_pay_b51ad57,
                      prefixIcon:
                          const Icon(Icons.account_balance_wallet_outlined),
                    ),
                  ),
                ),
              ],
            )
          else
            TextField(
              controller: salary,
              keyboardType: TextInputType.number,
              decoration: InputDecoration(
                labelText: HopeCopy.of(context).copy_monthly_salary_1d770dc,
                prefixIcon: const Icon(Icons.payments_rounded),
              ),
            ),
          const SizedBox(height: 11),
          if (kind == 'MISSION')
            TextField(
              controller: duration,
              keyboardType: TextInputType.number,
              decoration: InputDecoration(
                labelText: HopeCopy.of(context).copy_duration_hours_f4ca1cf,
                prefixIcon: const Icon(Icons.schedule_rounded),
              ),
            )
          else
            Column(
              children: [
                DropdownButtonFormField<String>(
                  initialValue: schedule,
                  decoration: InputDecoration(
                    labelText: HopeCopy.of(context).copy_schedule_3af1939,
                    prefixIcon: const Icon(Icons.timelapse_rounded),
                  ),
                  items: [
                    DropdownMenuItem(
                      value: 'PART_TIME',
                      child: Text(
                        HopeCopy.of(context).copy_part_time_086787b,
                      ),
                    ),
                    DropdownMenuItem(
                      value: 'FULL_TIME',
                      child: Text(
                        HopeCopy.of(context).copy_full_time_1e4bd4e,
                      ),
                    ),
                  ],
                  onChanged: (value) =>
                      setState(() => schedule = value ?? schedule),
                ),
                const SizedBox(height: 11),
                TextField(
                  controller: deadline,
                  decoration: InputDecoration(
                    labelText:
                        HopeCopy.of(context).copy_application_deadline_782fb61,
                    hintText: '2026-09-30',
                    prefixIcon: const Icon(Icons.event_outlined),
                  ),
                ),
              ],
            ),
          const SizedBox(height: 20),
          HopeSurface(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  HopeCopy.of(context).copy_hope_fee_2ea514e,
                  style: Theme.of(context).textTheme.titleMedium,
                ),
                const SizedBox(height: 6),
                Text(
                  kind == 'MISSION'
                      ? HopeCopy.of(context)
                          .copy_10_from_the_employer_and_10_from_the_candi_cf15dfa
                      : HopeCopy.of(context)
                          .copy_30_of_the_candidate_s_first_month_pay_is_c_d6da53b,
                  style: Theme.of(context).textTheme.bodyMedium,
                ),
              ],
            ),
          ),
          const SizedBox(height: 22),
          TextField(
            controller: accept,
            maxLines: 3,
            decoration: InputDecoration(
              labelText: HopeCopy.of(context)
                  .copy_acceptance_selection_criteria_a061aef,
              alignLabelWithHint: true,
              prefixIcon: const Icon(Icons.fact_check_outlined),
            ),
          ),
          const SizedBox(height: 24),
          FilledButton.icon(
            onPressed: busy ? null : submit,
            icon: const Icon(Icons.rocket_launch_rounded),
            label: busy
                ? const SizedBox(
                    width: 22,
                    height: 22,
                    child: CircularProgressIndicator(strokeWidth: 2),
                  )
                : Text(
                    HopeCopy.of(context).copy_publish_opportunity_9993b91,
                  ),
          ),
        ],
      ),
    );
  }

  Widget _selectCard(
    BuildContext context,
    IconData icon,
    String title,
    String sub,
    String value,
  ) {
    return PressableScale(
      onTap: () => setState(() => visibility = value),
      semanticLabel: '$title. $sub',
      child: HopeSurface(
        highlight: visibility == value,
        padding: const EdgeInsets.all(14),
        child: Row(
          children: [
            HopeIconTile(
              icon,
              filled: visibility == value,
              size: 42,
            ),
            const SizedBox(width: 9),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    style: Theme.of(context).textTheme.titleMedium,
                  ),
                  Text(
                    sub,
                    style: Theme.of(context).textTheme.bodyMedium,
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _TypeHero extends StatelessWidget {
  const _TypeHero({required this.kind, required this.onChanged});

  final String kind;
  final ValueChanged<String> onChanged;

  @override
  Widget build(BuildContext context) {
    return HopeSurface(
      highlight: true,
      padding: const EdgeInsets.all(17),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            HopeCopy.of(context)
                .copy_first_choose_what_kind_of_opportunity_you__f035ca9,
            style: Theme.of(context).textTheme.titleLarge,
          ),
          const SizedBox(height: 12),
          Row(
            children: [
              Expanded(
                child: _tile(
                  context,
                  'MISSION',
                  Icons.bolt_rounded,
                  HopeCopy.of(context).copy_mission_fb4c5e1,
                  HopeCopy.of(context)
                      .copy_a_defined_task_with_defined_pay_77b1068,
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: _tile(
                  context,
                  'JOB',
                  Icons.business_center_rounded,
                  HopeCopy.of(context).copy_job_ce2feba,
                  HopeCopy.of(context)
                      .copy_part_full_time_with_monthly_pay_abd5afd,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _tile(
    BuildContext context,
    String value,
    IconData icon,
    String title,
    String sub,
  ) {
    final selected = kind == value;

    return PressableScale(
      onTap: () => onChanged(value),
      semanticLabel: '$title. $sub',
      child: Container(
        padding: const EdgeInsets.all(13),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(20),
          gradient: selected
              ? const LinearGradient(
                  colors: [Color(0xFF6C4DFF), Color(0xFF22B8A7)],
                )
              : null,
          border: Border.all(color: Theme.of(context).dividerColor),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Icon(
              icon,
              color: selected ? Colors.white : AppColors.primary,
            ),
            const SizedBox(height: 8),
            Text(
              title,
              style: TextStyle(
                fontWeight: FontWeight.w900,
                color: selected ? Colors.white : null,
              ),
            ),
            const SizedBox(height: 3),
            Text(
              sub,
              style: TextStyle(
                fontSize: 11,
                height: 1.35,
                color: selected ? Colors.white70 : null,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
