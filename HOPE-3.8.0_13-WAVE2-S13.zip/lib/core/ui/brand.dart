import 'package:flutter/material.dart';
import '../../theme/app_theme.dart';

class HopeMark extends StatelessWidget {
  const HopeMark({super.key, this.size = 44, this.showText = true});
  final double size;
  final bool showText;

  @override
  Widget build(BuildContext context) {
    final mark = Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        gradient: const LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [Color(0xFF102A43), Color(0xFF0DBAA2), Color(0xFF7C5CFF)]),
        borderRadius: BorderRadius.circular(size * .32),
        boxShadow: const [
          BoxShadow(
              color: Color(0x306C4DFF), blurRadius: 20, offset: Offset(0, 9))
        ],
      ),
      child: CustomPaint(
          painter: _HopeLogoPainter(), child: const SizedBox.expand()),
    );
    if (!showText) return mark;
    return Row(mainAxisSize: MainAxisSize.min, children: [
      mark,
      const SizedBox(width: 10),
      Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text('HOPE',
            style: Theme.of(context)
                .textTheme
                .titleLarge
                ?.copyWith(fontWeight: FontWeight.w900, letterSpacing: 1.2)),
        Text('Jobs • Missions',
            style: Theme.of(context)
                .textTheme
                .labelSmall
                ?.copyWith(letterSpacing: .25)),
      ]),
    ]);
  }
}

class _HopeLogoPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final p = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = size.width * .12
      ..strokeCap = StrokeCap.round;
    p.color = Colors.white.withValues(alpha: .95);
    final w = size.width;
    final h = size.height;
    final path = Path()
      ..moveTo(w * .25, h * .68)
      ..lineTo(w * .25, h * .32)
      ..moveTo(w * .25, h * .50)
      ..lineTo(w * .75, h * .50)
      ..moveTo(w * .75, h * .32)
      ..lineTo(w * .75, h * .68);
    canvas.drawPath(path, p);
    final leaf = Paint()..color = const Color(0xFF8CF0C1);
    final lp = Path()
      ..moveTo(w * .42, h * .55)
      ..quadraticBezierTo(w * .62, h * .17, w * .78, h * .25)
      ..quadraticBezierTo(w * .72, h * .50, w * .42, h * .55)
      ..close();
    canvas.drawPath(lp, leaf);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

class SoftPill extends StatelessWidget {
  const SoftPill(
      {super.key,
      required this.icon,
      required this.label,
      this.color = AppColors.primary});
  final IconData icon;
  final String label;
  final Color color;
  @override
  Widget build(BuildContext context) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 11, vertical: 8),
        decoration: BoxDecoration(
            color: color.withValues(alpha: .10),
            borderRadius: BorderRadius.circular(999)),
        child: Row(mainAxisSize: MainAxisSize.min, children: [
          Icon(icon, size: 15, color: color),
          const SizedBox(width: 6),
          Text(label,
              style: TextStyle(
                  fontSize: 11, fontWeight: FontWeight.w900, color: color))
        ]),
      );
}
