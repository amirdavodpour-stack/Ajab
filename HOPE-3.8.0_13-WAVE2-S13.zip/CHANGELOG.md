# Changelog

## Unreleased — 2026-08-30

- Fixed a production fail-open gap: `RESET_TOKEN_DELIVERY_MODE` could remain `console` in production, allowing password-reset tokens to be logged instead of delivered over HTTPS webhook. Now hard-fails closed unless `RESET_TOKEN_DELIVERY_MODE=webhook` with an HTTPS delivery URL.
- Fixed two mobile/backend contract-test mismatches (`profile_page.dart`, `create_job_page.dart`) with no behavior change.
- Relocated two orphaned static contract checks (`network-error-contract`, `accessibility-rtl-contract`) from the untracked Flutter `test/` folder into `backend/tests/`, converted one to `node:test` format, and wired both into `npm run test:fast` / CI.
- Removed `docs/history/2026-08-29/` internal build/audit report dump; moved the one policy statement it was load-bearing for into `RELEASE-CHECKLIST.md` and repointed `tools/release_candidate_check.sh` at it.

## 3.8.0 — 2026-08-29

- Consolidated release/audit history under `docs/history/2026-08-29/`.
- Canonicalized 90+ scoring artifacts under `docs/audit/`.
- Made local JSON datastore and storage paths independent of the working directory.
- Added repository/editor hygiene guidance and `CONTRIBUTING.md`.
- Preserved production release gates as fail-closed and kept environment-dependent certification evidence explicit.

## 2026-08-29 — Wave 14
- Recommendation v2.2 adds freshness as an explicit weighted component and regression coverage for recency ordering.
- UX/accessibility contracts retained with localized semantics and touch-target requirements.


## 2026-08-29 — Wave 10 observability/performance
- Added staging performance smoke with bounded concurrency, p95/p99 latency budgets, and 5xx-rate threshold.
- Persisted machine-readable performance evidence as a staging certification artifact.
- Strengthened staging operational gate with explicit p95/p99 latency budgets.

## 2026-08-29 — Production hardening continuation

- Added `backend/src/notification_provider.js` as an HTTPS provider boundary with bounded retry for transient failures (`429/502/503/504`) and stable idempotency keys.
- Wired notification outbox delivery through the provider boundary.
- Added runtime HTTPS notification provider integration coverage.
- Made notification retry configuration explicit with `NOTIFICATION_MAX_ATTEMPTS` and `NOTIFICATION_RETRY_BASE_MS`.
- Added the notification provider integration test to the provider quality gate.

## 2026-08-29 — Wave 21
- Added staging resilience drill for single-replica failure, recovery, and full API outage detection.
- Added resilience topology contract tests and dedicated CI workflow.

## 2026-08-29 — Wave 19
- Added real HTTPS payment-provider adapter integration coverage with authentication and idempotency assertions.
- Added fail-closed production environment validation to the production release workflow.
- Added explicit payment-provider quality gate to the release-candidate checks.

## 2026-08-29 — Wave 17
- Added PostgreSQL-backed distributed rate limiting with hashed client keys and production fail-closed configuration.
- Added rate-limit schema/cleanup and contract coverage.
- Added live/health load smoke coverage.

## 2026-08-29 — Wave 7

- Added production release hard-gates for staging PostgreSQL E2E and S3 integration before APK signing.
- Added isolated PostgreSQL DR restore drill with retained evidence.
- Added Wave 7 certification document and release-candidate contract gate.


## 2026-08-29 — Wave 2 architecture hardening

- Extracted bounded request/business validation into `backend/src/policies/validation.js`.
- Extracted authentication/session and password-reset delivery policy into `backend/src/services/session.js`.
- Extracted PostgreSQL row-to-domain mappers into `backend/src/repository/mappers.js`.
- Added architecture contract tests so these module boundaries are regression-protected.
- Updated the Wave 0 documentation contract test to validate the current observability wording rather than obsolete claims.
- Re-ran the full offline backend suite: **154/154 tests pass**.

## 2026-08-29 — Wave 5 Recommendation 2.0

- Replaced city/distance-only recommendation scoring with explicit eight-factor weighted ranking.
- Personalized ranking now learns from first-party application history (skills, category, city, job kind and salary where available).
- Added explainable recommendation component scores and reasons to the recommendation API.
- Added recommendation-served analytics instrumentation.
- Added regression coverage for ranking weights, personalization, and explainability.
# 3.8.0

## Production hardening
- Added fail-closed production configuration checks for payment provider, token secrets, metrics token, and payment webhook secret.
- Added HSTS to production API responses.
- Prevented production Android builds from silently falling back to debug signing; enabled minification/resource shrinking for production.
- Added backend and Flutter quality gates to CI before APK assembly.
- Added production-hardening contract coverage for signing, configuration, and CI.

# 3.7.0

- UX, localization and accessibility hardening across core flows.
- Locale-aware search hints, transaction copy and directionality.
- Accessibility semantics and 48dp interactive target contracts.
- Refined light/dark interaction feedback and focus states.
- Added Phase 7 static UI contract tests.

# 3.6.4

- Phase 6: location intelligence and explainable recommendations.

## 3.6.3 — Phase 5 Notification & Event System (2026-08-29)
- Added durable in-app notifications with per-user read state and unread counts.
- Added notification preferences for in-app, push, email, job/application/payment updates and marketing.
- Added device-token registration for Android/iOS/Web and notification dispatch through the durable outbox.
- Added configurable push/email webhook adapters with bounded delivery timeouts; in-app delivery works without external providers.
- Added first-class Notifications screen to the mobile app.
- Added notification security, isolation, preference, device, lifecycle and UI contract tests.
- Fixed the pre-existing route-contract test import so the full check pipeline can run cleanly.


## 3.6.2 — Phase 4 Financial Engine (2026-08-29)
- Added fee-policy engine for Mission (10% employer + 10% worker) and Job (30% employer commission on first-month salary).
- Added transactional ledger journals, settlement records, refund lifecycle, signed payment webhooks, and admin financial summary.
- Added payment/refund idempotency, provider-charge calculation, and fail-safe outbox retry semantics.
- Added finance-specific unit, E2E, security, schema and route contract tests.
- External payment gateway remains behind the explicit provider boundary; simulator is still the only bundled provider.
## 3.6.2 — Phase 3 Admin Platform

- Added admin dashboard summary, user management, opportunity moderation, and audit log APIs/UI.
- Added protected lifecycle moderation and session revocation on user status changes.
- Updated OpenAPI contract and admin platform regression tests.


## Phase 2 — Recruitment Engine
- Added staged job application lifecycle with admin shortlist/forward/reject controls.
- Added employer interview, offer and hire workflow with one-hire-per-job guard.
- Added candidate application history and withdrawal.
- Hardened employer-facing candidate responses to strip identity data.
- Added lifecycle, security and mobile contract tests.

## 3.6.2 — Recruitment Engine
- Added shortlist → forward → interview → offer → hire application lifecycle.
- Added candidate self-service application history and withdrawal.
- Employer candidate views now expose only non-identifying professional information.
- Added owner-only interview, offer and hire transitions with single-hire invariant.
- Added API regression and security tests for the recruitment lifecycle.
## 3.6.2 — Phase 0/1 hardening
- Session restoration is now executed before the mobile router renders.
- Release metadata is aligned to 3.6.2 / Android versionCode 7.
- Added a hierarchical bilingual professional taxonomy with parent/child categories.
- Opportunity search now supports server-side `q` matching across opportunity text and category names.
- Flutter opportunity creation and Explore filters consume API categories rather than a hardcoded free-text field.
- CI now requires a real HTTPS `API_BASE_URL` secret instead of a placeholder host.

## 3.6.2
- Restored persisted authentication session on app startup.
- Unified release/version metadata.
- Introduced hierarchical bilingual professional taxonomy with active flags and ordering.
- Added server-side opportunity search (`q`) across title, description, city and category names.

# Changelog

## 2026-08-29 — Release hardening pass

- Added bounded integer validation for operational configuration values so invalid, negative or non-integer production settings fail at boot instead of degrading into undefined runtime behavior.
- Strengthened the production release workflow to run backend quality/product/performance gates and Flutter analyze/tests before signing the APK.
- Added a SHA-256 checksum artifact for the production APK.
- Reconciled README/changelog language with the current admin, analytics and observability implementation.

Condensed from the project's iterative build history. Entries are grouped
by theme rather than by round number.

## Backend: PostgreSQL migration

- Introduced a relational PostgreSQL schema (`backend/src/db.js`) alongside
  the original single-file JSON store, with a repository layer
  (`backend/src/repository.js`) that issues parameterized SQL with
  row-level locking for every state-changing action: registration, job
  create/publish/start/deliver/accept, offer create/accept, funding,
  payment release, refresh-token rotation, and password reset.
- Moved payment `createHold`/`releaseHold` onto a durable outbox
  (`backend/src/outbox_worker.js`): the funding/release transaction writes
  the outbox event atomically with the state change, so a worker crash
  mid-call cannot leave a payment stuck between states; failed events are
  retried instead of permanently stuck, and provider calls carry an
  explicit idempotency key.
- Removed an early PostgreSQL advisory single-writer lock in favor of
  row-level transaction locking, so multiple API replicas can mutate
  concurrently without corrupting shared state.
- **Fixed a remaining consistency gap**: several read paths (single-job
  detail, job create/publish/start/deliver/accept responses, payment
  views) still resolved the job's owner/provider/offer-count from the
  process-local in-memory cache even when `DATABASE_URL` was set, so a
  reply from one API replica could show `owner: null`/stale offer counts
  for data created on a different replica. `jobView`/`paymentView` in
  `backend/src/app.js` now resolve this through the same repository layer
  used everywhere else, and a related dead in-memory write (pushing every
  newly registered user into a cache array that was never read back,
  which grew unbounded for the life of the process) was removed.

## Backend: security & correctness

- Switched password hashing from synchronous to asynchronous PBKDF2 so a
  login/register call no longer blocks the event loop for the duration of
  the hash; bounded the accepted iteration count on stored hashes.
- Fixed `enforceJobState` calling the wrong helper (a state-*transition*
  check instead of a current-state membership check), which had been
  rejecting nearly every legitimate lifecycle action (publish, offer
  accept, start, deliver, evidence, release) with `409 INVALID_STATE`.
- Reordered the payment-funding idempotency check to run before the job
  state guard, so a retried request with the same `Idempotency-Key`
  returns the original payment instead of a spurious 409.
- Required a user-bound, expiring upload intent for direct-to-S3 uploads,
  consumed on completion; added file-signature validation (not just
  declared content-type) for both direct and proxied uploads.
- Enforced production-only invariants at boot: real token secrets,
  `DATABASE_URL`, HTTPS `PUBLIC_BASE_URL`, explicit CORS origins,
  `STORAGE_BACKEND=s3`, and webhook-based password-reset delivery.

## Mobile (Flutter)

- Fixed a spurious `Navigator.pop()` assertion after login (the login
  page is the router's `home`, never pushed).
- Added an `onUnauthorized` hook plus an actual access-token refresh flow
  in `ApiClient` (request retried once after a silent refresh; falls back
  to logout only if the refresh itself fails).
- Wired evidence uploads through the existing retry queue (previously
  instantiated but never called, so uploads had no retry despite the UI
  implying one).
- Made the home tab bar lazily build each tab on first visit instead of
  eagerly constructing all four, and removed a duplicate embedded jobs
  list that had been firing `GET /jobs` twice on every login.
- Added client-side validation for job creation (required fields,
  description length, numeric/positive budgets and duration, budget
  ordering) so invalid input is caught before an API call.
- Fixed the Android adaptive launcher icon (was a raw vector, not
  wrapped in an `<adaptive-icon>`) and removed an unreferenced duplicate
  icon.


## 3.6.0 — HOPE Jobs & Missions
- Added first-class Mission vs Job opportunity model.
- Added public vs specialized visibility and category-oriented discovery.
- Added city/location personalization controls and alternate-city selection.
- Added bilingual Persian/English app language setting.
- Expanded settings: notifications, personalized recommendations, quiet hours, compact cards and appearance modes.
- Added admin moderation panel, job removal and pre-employer candidate selection workflow.
- Added job application endpoint with identity-minimization for employer-facing selected candidates.
- Added HOPE fee policy metadata: missions 10% employer + 10% candidate; jobs 30% of first-month salary from employer.
- Refreshed HOPE branding, visual hero treatment and opportunity cards.

## 3.8.0

### Wave 11 — Integration & Release Readiness
- Added read-only HTTPS staging smoke gate.
- Added operations/DR contract tests.
- Removed duplicate `trust_reports` migration declaration.
- Production release workflow now requires staging smoke before signing.

 — Wave 3 Notifications

- Added authenticated Push/Email provider delivery for outbox notifications.
- Push dispatch now resolves enabled device tokens per user and sends one provider request per target.
- Email dispatch now resolves the user's email address before delivery.
- Production notification providers require HTTPS and a sufficiently long provider token.
- Added Wave 3 notification runtime contract tests.

## 3.8.0 — Wave 4 Analytics & Crash Reporting

- Added first-party analytics event ingestion and funnel summaries.
- Added mobile crash/error ingestion with privacy filtering and redaction.
- Added Flutter telemetry client and global error handlers.
- Added database-backed analytics idempotency.
- Added Wave 4 contract tests and documentation.

## 3.8.0-wave6

- Added masked employer candidate comparison.
- Added job trust-reporting and admin trust queue.
- Added PostgreSQL persistence for trust reports.
- Added Wave 6 recruitment/trust contract tests and documentation.

## Wave 8 — UX & Localization Foundation (2026-08-29)

- Responsive large-screen content constraint.
- Skeleton opportunity loading states.
- Accessibility live-region semantics for feed counts.
- Haptic feedback for press interactions.
- Persian readability typography tuning.
- Localization migration explicitly tracked as a release gate.

## 3.8.0-wave4 — 2026-08-29
- Added authenticated account data export and privacy deletion flows.
- Added telemetry property sanitization and mobile telemetry opt-in consent.
- Added recommendation freshness decay and diversity-aware ranking without breaking the existing component contract.
- Added privacy and recommendation regression coverage.
- Verification: 163 backend tests passing, 1 skipped; syntax, contract, performance smoke and backup gates passing.

## 3.8.0 — Wave 5 (2026-08-29)
- Hardened production release configuration and container runtime.
- Added HTTPS PSP-facade payment provider adapter and fail-closed production env validation.
- Hardened Docker runtime with non-root user, read-only root filesystem, loopback binding and liveness healthcheck.
- Added CI SBOM generation and release-hardening contracts.

### Wave 9 — Security & Release Final Pass
- Removed reset-token material from password-reset delivery logs; console/test delivery now records metadata only.
- Added regression coverage preventing bearer-equivalent password-reset tokens from entering logs.
- Revalidated the full backend suite after the security hardening change.

## 2026-08-29 — Wave 13 Architecture & Push Boundary
- Extracted notification HTTP routes from the monolithic backend composition root into a dependency-injected route module.
- Added a vendor-neutral mobile push-token provider interface and automatic token registration when a native provider is injected.
- Updated notification contracts to protect the new architectural boundary.


## 3.8.0 — Wave 16 (2026-08-29)
- Extracted Jobs, Offers, and Applications HTTP routes from `backend/src/app.js` into dependency-injected modules.
- Reduced the backend composition root from 938 to 620 lines without changing the public route surface.
- Updated route/static contracts to test the new modules directly and added an architecture regression guard against reintroducing the monolith.
- Verification: full offline backend suite 180/180 passing; product and security/release waves passing; `check:all` passing.
## 3.8.0 — Wave 18
- Added reproducible two-replica staging topology with shared PostgreSQL and Nginx gateway.
- Added staging boot/smoke harness and topology regression contracts.
- Explicitly preserves PostgreSQL-backed distributed rate limiting in staging.


## 3.8.0 — Wave 20 (2026-08-29)
- Corrected production release environment validation to use production database and S3 secret names.
- Added a regression guard preventing staging data-store secrets from entering the production environment-contract step.
- Stabilized the local 500-request load-smoke gate against CI host scheduling variance while preserving bounded latency checks.

## 3.8.0 — 2026-08-29 — Wave 26
- Hardened production release workflow to run `npm ci` before backend SBOM and quality tooling.
- Added regression coverage for deterministic dependency installation order.
- Revalidated release, operations, staging, Android signing, and integrity-manifest contracts.
.github/workflows/* pinned to immutable SHAs; production/resilience CI uses Node 24; temporary production keystore is removed after release attempt.

## 2026-08-29 — P8 Integration/Release Readiness
- Hardened production CORS validation against wildcard entries.
- Enforced HTTPS for configured custom production S3 endpoints.
- Added regression coverage and documented externally dependent release gates.

## Wave 5 — Android runtime/release certification hardening

- Added `tools/android-release-contract.sh` to enforce cleartext denial, SDK baselines, pilot-vs-production signing boundaries, and unexpected HTTP endpoint detection.
- Added Java 17 setup to Android-capable CI jobs for reproducible Gradle execution.
- Strengthened device integration smoke to require HTTPS in CI mode.


## Wave 6 — Resilience & Failure Injection — 2026-08-29

- Added explicit provider failure-injection tests for payment retry exhaustion and notification permanent-4xx handling.
- Added `npm run test:failure-injection` and included it in the aggregate `check:all` gate.
- Added failure-injection validation to the staging resilience workflow before the two-replica drill.
- Verified provider behavior: retryable 503s are retried up to the configured maximum; permanent 4xx responses are not retried.

- Hardened DR restore drill with `pg_restore --exit-on-error` plus required-table and SQL usability checks after restore.

## Wave 7 — Android runtime certification — 2026-08-29
- Extended Android integration smoke with registration, authenticated provider-profile access, and refresh-token rotation checks.
- Added HTTPS-only runtime endpoint contract validation for device certification.
- Wired the endpoint contract into the Android device integration workflow before emulator execution.
- Verification: backend fast 83/83, contract 40/40, product 9/9, failure-injection 2/2, provider 3/3 passing.

## Wave 9 — Certification evidence isolation — 2026-08-29
- Moved DR restore evidence ownership to the reusable staging certification workflow.
- Added an explicit `certification_status=PASS` workflow output consumed by production release.
- Removed the stale production DR artifact upload that referenced a non-existent runner workspace.
- Added regression coverage for staging-owned evidence and fail-closed production gating.

## Wave 9 — Certification evidence isolation — 2026-08-29
- Corrected the release-evidence contract so DR evidence is owned by staging certification.
- Added explicit reusable-workflow certification output and fail-closed production gating.
- Removed the stale production DR artifact upload path.
- Added regression coverage for evidence ownership and certification boundaries.

## 2026-08-29 — Wave 11
- Added W3C `traceparent` parsing and response propagation with stable trace IDs.
- Added structured service identity to runtime logs.
- Added optional HTTPS operational alert webhook with cooldown and no secret leakage.
- Added Wave 11 observability/alert regression coverage and wired it into fast checks.

## 2026-08-29 — Wave 12
- Added dedicated DR restore verification workflow with isolated source/drill PostgreSQL services.
- DR drill now fails closed when source and drill database URLs are identical.
- DR CI captures restore evidence as a retained workflow artifact.

## 2026-08-29 — Wave 11
- Privacy export hardened to v1.2 with recursive secret/internal-field redaction.
- Recommendation engine versioned and given ranking-quality evaluation utilities.
