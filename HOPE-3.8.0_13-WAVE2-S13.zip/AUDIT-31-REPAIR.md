# HOPE 3.8.0+11 — Audit 31 Repair Record

Reference audit: `HOPE-DEFINITIVE-AUDIT-31.zip` / Run `33623908818`.

## Repairs applied

1. **Android debug configuration** — production signing is no longer validated merely because Gradle configures the `release` build type. Production credentials are required only when an actual release task is requested. `assembleDebug` therefore remains buildable without production secrets.
2. **Pilot APK path** — `BUILD_PROFILE=pilot` remains the explicit CI default and uses the debug signing configuration for the non-production pilot artifact.
3. **CI project discovery** — `.github/workflows/main.yml` now recursively discovers the unique Flutter root instead of assuming the repository contains a directory named `source`.
4. **CI artifact gate** — the pilot workflow fails unless a non-empty APK over 1 MB exists and its package/version/hash evidence is present.
5. **Production environment contract test** — `npm run test:production-env` now invokes a deterministic fake fixture and still tests the unchanged production validator. No real secret is stored.
6. **S3 integration test** — the test now skips cleanly when no S3-compatible service is available in a non-strict environment. Staging certification sets `S3_REQUIRE_LIVE=1`, so a real staging outage remains a hard failure.
7. **Toolchain consistency** — Flutter setup in staging/device/production workflows is aligned to Flutter 3.47.1.

## Known external prerequisite

A production APK still requires the real production keystore secrets. The pilot APK does not. The GitHub repository must also execute the corrected workflow from this project tree (or use its recursive project-root discovery when the Flutter project is nested).

## Verification performed in this environment

- `bash -n` on modified shell scripts: PASS
- Node syntax check for S3 test: PASS
- backend `npm run check`: PASS
- backend `npm run test:production-env`: PASS
- backend `npm run test:s3`: PASS with SKIP when MinIO is absent

Flutter/Gradle APK compilation was not executed locally because this environment does not contain Flutter/Android SDK. The GitHub pilot workflow is the authoritative APK build gate.
